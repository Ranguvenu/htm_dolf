<?php
require_once('../../config.php');
global $CFG, $PAGE, $OUTPUT, $DB;
require_login();
$systemcontext = context_system::instance();
if(!has_capability('local/organization:manage_trainee', $systemcontext)) {
    print_error(get_string('permissionerror', 'local_learningtracks'));
}
$id = required_param('id', PARAM_INT);
$PAGE->set_context(context_system::instance());
$renderer = $PAGE->get_renderer('local_learningtracks');
$track = $renderer->track_check($id);
$PAGE->set_url('/local/learningtracks/learningpathview.php');
$PAGE->set_title(get_string('mylearningtracks','local_learningtracks'));
$PAGE->set_heading(get_string('viewitems','local_learningtracks'));
$PAGE->navbar->add(get_string('mylearningtracks','local_learningtracks'),new moodle_url('/local/learningtracks/learningpath.php'));
$PAGE->navbar->add(get_string('learning_track_details', 'local_learningtracks'), new moodle_url('/local/learningtracks/learningpathview.php?id='.$id));
$content = $renderer->get_mytrackview($id);
echo $OUTPUT->header();
echo $content;
echo $OUTPUT->footer();
