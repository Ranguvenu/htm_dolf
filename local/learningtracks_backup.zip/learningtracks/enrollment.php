<?php
ini_set('memory_limit', '-1');
define('NO_OUTPUT_BUFFERING', true);
require('../../config.php');
require_once($CFG->dirroot . '/local/learningtracks/lib.php');
require_once($CFG->dirroot . '/local/learningtracks/filters_form.php');
require_once("$CFG->libdir/externallib.php");
require_once($CFG->dirroot.'/course/lib.php');
require_once($CFG->dirroot.'/course/externallib.php');
global $CFG,$DB,$USER,$PAGE,$OUTPUT,$SESSION;
 
$view       = optional_param('view','page', PARAM_RAW);
$type       = optional_param('type','', PARAM_RAW);
$lastitem   = optional_param('lastitem',0, PARAM_INT);
$track_id     = required_param('trackid', PARAM_INT);

$submit_value = optional_param('submit_value','', PARAM_RAW);
$add        = optional_param('add',array(), PARAM_RAW);
$remove     = optional_param('remove',array(), PARAM_RAW);
$options       = optional_param('options',array(), PARAM_RAW);

$programlist     = optional_param('program_enroll',array(), PARAM_RAW);
$query     =optional_param('query',array(), PARAM_RAW);
$examoptions = json_decode($options);
$exam_list  = $examoptions->examlist;
$program_list  = $examoptions->programlist;

$trackobj = new \local_learningtracks\learningtracks();
$context = context_system::instance();
$backurl = new moodle_url('/local/learningtracks/enrollment.php',['trackid'=> $track_id]);
$PAGE->set_context($context);
$PAGE->set_url($backurl);
$renderer = $PAGE->get_renderer('local_learningtracks');
$track = $renderer->track_check($track_id);
$learningtrack = $DB->get_record('local_learningtracks', ['id' => $track_id], '*', MUST_EXIST);
$trackname = get_string('trackname', 'local_learningtracks', $learningtrack->name);
$PAGE->requires->jquery();
$PAGE->requires->jquery_plugin('ui');
$PAGE->requires->js('/local/learningtracks/js/jquery.bootstrap-duallistbox.js',true);
$PAGE->requires->css('/local/learningtracks/css/bootstrap-duallistbox.css');
$PAGE->set_title(get_string('enrolled','local_learningtracks'));
if(!$add && !$remove){
    $PAGE->set_heading($trackname);
}
$PAGE->navbar->add(get_string('manage_learningtracks','local_learningtracks'),new moodle_url('/local/learningtracks/index.php'));
$PAGE->navbar->add($learningtrack->name, new moodle_url('/local/learningtracks/view.php?id='.$track_id));
$PAGE->navbar->add(get_string('enrolled','local_learningtracks'));
//$PAGE->requires->js_call_amd('theme_academy/cardPaginate', 'filteringData', array($context));
// require_login();
$programlist = array();
$examlist = array();
foreach ($_REQUEST as $key => $value) {
    if(strpos($key, 'tp-') !== false){
        $programlist[] = $value;
    }
    if(strpos($key, 'exam-') !== false){
        $examlist[] = $value;
    }
}

/*if($view == 'ajax'){
    $option = (array)json_decode($_GET["options"],false);
    $search_query  = ['query' => $query];
    $options  = array_merge($option,$search_query);
    $select_from_users = (new \local_learningtracks\learningtracks)->learningtrack_enrolled_users($type, $track_id,$options,false,$offset1=-1,$perpage=50,$lastitem);
    echo json_encode($select_from_users);
}*/
echo $OUTPUT->header();
$roleid = $DB->get_field('role', 'id',array('shortname' => 'trainee'));

if ($add) {
    $trackobj->enrol_track($add, $track_id, $roleid,$exam_list, $program_list);
}
if ($remove) {
   $trackobj->unenrol_track($remove, $track_id, $roleid);
}

$fromusers = [];
$tousers = [];
if ($learningtrack) {

    $entity_data = (new local_learningtracks\learningtracks)->get_learningtrack_entities($track_id);

    if(!is_siteadmin()){

        $manage_organizationofficial=false;

        if(has_capability('local/organization:manage_organizationofficial', $context)){


            $product_attributes=(new \tool_product\product)->get_button_order_seats($label=get_string('booknow','local_learningtracks'),'local_learningtracks','id',$track_id,$entity_data['lowestseats'],0, $action='booknow',$grouped=$track_id);

            $manage_organizationofficial=true;

         }else{

            $product_attributes=(new \tool_product\product)->get_product_attributes($track_id, 5, 'addtocart', false, 0, 1, false, $track_id);

         }

        

        $data = [
            'data' => $entity_data,
            'examlist' => json_encode($examlist),
            'programlist' => json_encode($programlist),
            'trackid' => $track_id,
            'product_attributes' => $product_attributes,
            'manage_organizationofficial'=>$manage_organizationofficial
        ];


        echo $OUTPUT->render_from_template('local_learningtracks/enrolment_entities', $data);

    }

    if(is_siteadmin() || has_capability('local/organization:manage_organizationofficial', $context)){

        $email        = null;
        $filterlist = array('useremail');
        $filterparams = array('options'=>null, 'dataoptions'=>null);
        $mform = new filters_form($PAGE->url, array('filterlist' => $filterlist, 'trackid' => $track_id,'filterparams' => $filterparams, 'action' => 'learningtrackuser_enrolment'));
        if ($mform->is_cancelled()) {
            redirect($PAGE->url);
        } else {
            $filterdata =  $mform->get_data();
            if($filterdata){
                $collapse = false;
            } else{
                $collapse = true;
            }
            $email = !empty($filterdata->email) ? implode(',', $filterdata->email) : null;
        }
        $options = array('context' => $context->id,
                        'trackid' => $track_id,
                        'email' => $email, 
                        'examlist' => $examlist, 
                        'programlist' => $programlist, 
                        'query' => $query);
        $users = (new \local_learningtracks\learningtracks)->learningtrack_enrolled_users($track_id, $options);
        
        if(!empty($entity_data['programs']) || !empty($entity_data['exams'])){
            print_collapsible_region_start(' ', 'filters_form', ' '.' '.get_string('filters'), false, $collapse);
            $mform->display();
            print_collapsible_region_end();

            if ($learningtrack) {
                $myJSON = json_encode($options);
                $renderer = $PAGE->get_renderer('local_learningtracks');
                $renderer->trackenrollment($users['availableuserscount'], $users['enrolledusers'], $users['enrolleduserscount'], $users['availableusers'], $myJSON, $track_id, $examlist, $roleid);
            } else {
                echo "<div class='alert alert-info'>".get_string('enrolfiltersmandatory', 'local_exams')."</div>";
            }
        }
    }
}

$backurl = new moodle_url('/local/learningtracks/view.php?id='.$track_id.'');
echo $OUTPUT->footer();
