import HomePage from 'theme_academy/homepage';
import $ from 'jquery';

const Selectors = {
    actions: {
        rmselectall: '#select_remove',
        rmunselectall: '#remove_select',
        unenrollbtn: '.box3 .remove',
        enrolbtn: '.box3 .move',
        addselectall: '#select_add',
        addunselectall: '#add_select',
        unenrolledusers: '#bootstrap-duallistbox-nonselected-list_duallistbox_courses_users',
        enrolledusers: '#bootstrap-duallistbox-selected-list_duallistbox_courses_users',
        learningitem: '.learningitem'
    },
};
export const init = () => {
    document.addEventListener('click', function(e) {
        e.stopImmediatePropagation();
        let rmselectall = e.target.closest(Selectors.actions.rmselectall);
        if (rmselectall) {
            e.preventDefault();
            $(Selectors.actions.enrolledusers + ' option').prop('selected', true);
            $(Selectors.actions.unenrollbtn).prop('disabled', false).val('Remove_All_Users');

            $(Selectors.actions.enrolbtn).prop('disabled', true);
            $(Selectors.actions.unenrolledusers + ' option').prop('selected', false).val('Add Selected Users');
        }

        let rmunselectall = e.target.closest(Selectors.actions.rmunselectall);
        if (rmunselectall) {
            e.preventDefault();
            $(Selectors.actions.enrolledusers + ' option').prop('selected', false);
            $(Selectors.actions.unenrollbtn).prop('disabled', true).val('Remove Selected Users');
        }

        let addselectall = e.target.closest(Selectors.actions.addselectall);
        if (addselectall) {
            e.preventDefault();
            let learningitems = $(Selectors.actions.learningitem);
            let items = [];
            let errors = [];
            $.each(learningitems, function(key, value){
                let name=$(value).attr('name');
                if (!items.includes(name)) {
                    items.push(name);
                    if(!$('input[name='+name+']').is(':checked')){
                        errors.push(name);
                    } 
                } 
            });
           if(errors.length > 0){
                alert('Select all variations');
                return false;
           }else{
                $(Selectors.actions.unenrolledusers + ' option').prop('selected', true);
                $(Selectors.actions.enrolbtn).prop('disabled', false).val('Add_All_Users');

                $(Selectors.actions.unenrollbtn).prop('disabled', true);
                $(Selectors.actions.enrolledusers + ' option').prop('selected', false).val('Remove Selected Users');
            }
        }
         let addunselectall = e.target.closest(Selectors.actions.addunselectall);
         if (addunselectall) {
            e.preventDefault();
            $(Selectors.actions.unenrolledusers + ' option').prop('selected', false);
            $(Selectors.actions.enrolbtn).prop('disabled', true).val('Add Selected Users');
        }
        let enrolledusers = e.target.closest(Selectors.actions.enrolledusers);
        if (enrolledusers) {
            if(this.value!=''){
                $(Selectors.actions.unenrollbtn).prop('disabled', false);
                $(Selectors.actions.enrolbtn).prop('disabled', true);
            }
        }
        let unenrolledusers = e.target.closest(Selectors.actions.unenrolledusers);
        if (unenrolledusers) {
            if(this.value!=''){
                let learningitems = $(Selectors.actions.learningitem);
                let items = [];
                var errors = [];
                $.each(learningitems, function(key, value){
                    let name=$(value).attr('name');
                    if (!items.includes(name)) {
                        items.push(name);
                        if(!$('input[name='+name+']').is(':checked')){
                            errors.push(name);
                        } 
                    } 
                });
               if(errors.length > 0){
                    $(this).val([]);
                    alert('Select all variations');
                    return false;
               }else{
                    $(Selectors.actions.enrolbtn).prop('disabled', false);
                    $(Selectors.actions.unenrollbtn).prop('disabled', true);
                }
            }
        }

    });

    // $('.dual_select').bind('scroll', function()
    // {
    //   if($(this).scrollTop() + $(this).innerHeight()>=$(this)[0].scrollHeight)
    //   {
    //     var get_id=$(this).attr('id');
    //     if(get_id==Selectors.actions.enrolleduser){
    //         var type='remove';
    //         var total_users={{from_userstotal}};
    //     }
    //     if(get_id==Selectors.actions.unenrolledusers){
    //         var type='add';
    //         var total_users={{to_userstotal}};
    //     }
    //     var count_selected_list=$('#'+get_id+' option').length;
    //     var lastValue = $('#'+get_id+' option:last-child').val();
    //   if(count_selected_list<total_users){  
    //         var selected_list_request = $.ajax({
    //             method: 'GET',
    //             url: M.cfg.wwwroot + '/local/learningtracks/enrollment.php?test=1&options={{myJSON}}',
    //             data: {id: {{track_id}}, type:type,view:'ajax',lastitem:lastValue},
    //             dataType: 'html'
    //         });  
    //         var appending_selected_list = '';
    //         selected_list_request.done(function(response){
    //         response = jQuery.parseJSON(response);
    //         $.each(response, function (index, data) {
    //             appending_selected_list = appending_selected_list + '<option value=' + index + '>' + data + '</option>';
    //         });
    //         $('#'+get_id+'').append(appending_selected_list);
    //         });
    //     }
    //   }
    // });

}



//   $( document ).ready(function() {

//     jQuery(
//         function($)
//         {
//           $('.dual_select').bind('scroll', function()
//             {
//               if($(this).scrollTop() + $(this).innerHeight()>=$(this)[0].scrollHeight)
//               {
//                 var get_id=$(this).attr('id');
//                 if(get_id=='bootstrap-duallistbox-selected-list_duallistbox_courses_users'){
//                     var type='remove';
//                     var total_users={{from_userstotal}};
//                 }
//                 if(get_id=='bootstrap-duallistbox-nonselected-list_duallistbox_courses_users'){
//                     var type='add';
//                     var total_users={{to_userstotal}};
//                 }
//                 var count_selected_list=$('#'+get_id+' option').length;
//                 var lastValue = $('#'+get_id+' option:last-child').val();
//               if(count_selected_list<total_users){  
//                     var selected_list_request = $.ajax({
//                         method: 'GET',
//                         url: M.cfg.wwwroot + '/local/learningtracks/enrollment.php?test=1&options={{myJSON}}',
//                         data: {id: {{track_id}}, type:type,view:'ajax',lastitem:lastValue},
//                         dataType: 'html'
//                     });  
//                     var appending_selected_list = '';
//                     selected_list_request.done(function(response){
//                     response = jQuery.parseJSON(response);
//                     $.each(response, function (index, data) {
//                         appending_selected_list = appending_selected_list + '<option value=' + index + '>' + data + '</option>';
//                     });
//                     $('#'+get_id+'').append(appending_selected_list);
//                     });
//                 }
//               }
//             })
//         }
//     );
// });

    // $('#select_remove').click(function() {
    //     $('#bootstrap-duallistbox-selected-list_duallistbox_courses_users option').prop('selected', true);
    //     $('.box3 .remove').prop('disabled', false);
    //     $('#user_unassign_all').val('Remove_All_Users');

    //     $('.box3 .move').prop('disabled', true);
    //     $('#bootstrap-duallistbox-nonselected-list_duallistbox_courses_users option').prop('selected', false);
    //     $('#user_assign_all').val('Add Selected Users');
    // });
    // $('#remove_select').click(function() {
    //     $('#bootstrap-duallistbox-selected-list_duallistbox_courses_users option').prop('selected', false);
    //     $('.box3 .remove').prop('disabled', true);
    //     $('#user_unassign_all').val('Remove Selected Users');
    // });

        // $('#select_add').click(function() {

    //      let learningitems = $('.learningitem');
    //         let items = [];
    //         let errors = [];
    //         $.each(learningitems, function(key, value){
    //             let name=$(value).attr('name');
    //             if (!items.includes(name)) {
    //                 items.push(name);
    //                 if(!$('input[name='+name+']').is(':checked')){
    //                     errors.push(name);
    //                 } 
    //             } 
    //         });
    //        if(errors.length > 0){
    //             alert('Select all variations');
    //             return false;
    //        }else{
    //             $('#bootstrap-duallistbox-nonselected-list_duallistbox_courses_users option').prop('selected', true);
    //             $('.box3 .move').prop('disabled', false);
    //             $('#user_assign_all').val('Add_All_Users');

    //             $('.box3 .remove').prop('disabled', true);
    //             $('#bootstrap-duallistbox-selected-list_duallistbox_courses_users option').prop('selected', false);
    //             $('#user_unassign_all').val('Remove Selected Users');
    //         }
    // });


    // $('#add_select').click(function() {
            
    //             $('#bootstrap-duallistbox-nonselected-list_duallistbox_courses_users option').prop('selected', false);
    //             $('.box3 .move').prop('disabled', true);
    //             $('#user_assign_all').val('Add Selected Users');
             
    // });
    //     $('#bootstrap-duallistbox-selected-list_duallistbox_courses_users').on('change', function() {
    //     if(this.value!=''){
    //         $('.box3 .remove').prop('disabled', false);
    //         $('.box3 .move').prop('disabled', true);
    //     }
    // });
    //     $('#bootstrap-duallistbox-nonselected-list_duallistbox_courses_users').on('change', function() {
    //     if(this.value!=''){
    //         let learningitems = $('.learningitem');
    //         let items = [];
    //         var errors = [];
    //         $.each(learningitems, function(key, value){
    //             let name=$(value).attr('name');
    //             if (!items.includes(name)) {
    //                 items.push(name);
    //                 if(!$('input[name='+name+']').is(':checked')){
    //                     errors.push(name);
    //                 } 
    //             } 
    //         });
    //        if(errors.length > 0){
    //             $(this).val([]);
    //             alert('Select all variations');
    //             return false;
    //        }else{
    //             $('.box3 .move').prop('disabled', false);
    //             $('.box3 .remove').prop('disabled', true);
    //         }
    //     }
    // });