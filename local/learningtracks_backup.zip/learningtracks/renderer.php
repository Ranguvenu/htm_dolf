<?php
/*
* This file is a part of e abyas Info Solutions.
*
* Copyright e abyas Info Solutions Pvt Ltd, India.
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*
* @author e abyas  <info@eabyas.com>
*/
/**
 * Defines learningtracks rendering functions.
 *
 * @package    local_learningtracks
 * @copyright  e abyas  <info@eabyas.com>
 */
defined('MOODLE_INTERNAL') || die;

use context_system;
use html_table;
use html_writer;
use local_learningtracks\learningtracks as learningtracks;
use plugin_renderer_base;
use moodle_url;
use stdClass;
use single_button;
use core_user;
use core_completion\progress;
require_once($CFG->dirroot . '/local/learningtracks/lib.php');
require_once($CFG->dirroot . '/local/trainingprogram/lib.php');
require_once($CFG->dirroot .'/local/exams/lib.php');
class local_learningtracks_renderer extends plugin_renderer_base {
    public function render_learningtracks($page)
    {
        $data = $page->export_for_template($this);                                                                                  
        return parent::render_from_template('local_trainingprogram/mainpage', $data);         
    }

    public function get_content($filter = false) {
        $systemcontext = context_system::instance();
        $options = array('targetID' => 'manage_learningtracks','perPage' => 5, 'cardClass' => 'col-md-6 col-12', 'viewType' => 'card');
        $options['methodName'] = 'local_learningtracks_get_learningtracks';
        $options['templateName'] = 'local_learningtracks/learningtracks_list';
        $options = json_encode($options);
        $filterdata = json_encode(array());
        $dataoptions = json_encode(array('contextid' => $systemcontext->id));
        $context = [
                'targetID' => 'manage_learningtracks',
                'options' => $options,
                'dataoptions' => $dataoptions,
                'filterdata' => $filterdata,
        ];
        if($filter){
            return  $context;
        }else{
            return  $this->render_from_template('theme_academy/cardPaginate', $context);
        }
    }

    public function lis_tracks($tracks) {
        global $USER, $CFG, $DB;
        $systemcontext = context_system::instance();
        //$gettracks = learningtracks::get_listof_learningtracks($stable, $filterdata);
      // $tracks = array_values($gettracks['tracks']);
        $row = array();
        $stable = new \stdClass();
        $stable->thead = true;
        $count = 0;
        foreach ($tracks as $list) {
            $record = array();
            $record['id'] = $list->id;
            $record['name'] = $list->name;
            $record['code'] = $list->code;
            $statusarry = array(0 => 'Pending', 1 => 'Approve', 2 => 'Completed', 3 => 'Rejected');
            $record['status'] = $statusarry[$list->status];
            $stable->trackid = $list->id;
            $stable->start = 0;
            $stable->length = 1;
            $trackitems =  (new learningtracks)->get_listof_learningitems($list->id, $stable);
            $learningitems_count = $trackitems['learningitemscount'];
            $trackusers = (new learningtracks)->get_listof_users($list->id, $stable);
            $enrollcount = $trackusers['userscount'];
            $completed_count = (new learningtracks)->completed_items_count($list->id);
            $record['completed_count'] =  $completed_count;
            $record['nolearningitems'] =  $learningitems_count;
            $record['enrollcount'] =  $enrollcount;
            $record['action'] = false;
            $record['delete'] = false;
            $record['edit'] = false;
            $record['view'] = false;
            $record['assignuser'] = false;
            $assignuser_url = $CFG->wwwroot.'/local/learningtracks/enrollment.php?trackid='.$list->id;
            $record['assignuser_url'] = $assignuser_url;
            if(is_siteadmin() || has_capability('local/learningtracks:editlearningtracks', $systemcontext)) {
                $record['edit'] = true;
                $record['action'] = true;
            }
            if(is_siteadmin() || has_capability('local/learningtracks:deletelearningtracks', $systemcontext)) {
                $record['delete'] = true;
                $record['action'] = true;
            }
            $record['viewurl'] = $CFG->wwwroot."/local/learningtracks/view.php?id=".$list->id;
            if(is_siteadmin() || has_capability('local/learningtracks:viewlearningtracks', $systemcontext)) {
                $record['view'] = true;
                $record['action'] = true;
               
            }
            if(is_siteadmin() || has_capability('local/learningtracks:manageusers', $systemcontext)) {
                $record['assignuser'] = true;
                $record['action'] = true;
            }
            $record['count'] = $count+1;
            $count++;
            $row[] = $record;
         }
        return array_values($row);
    }

    public function get_content_viewtrack($trackid) {
        global $OUTPUT, $CFG, $DB, $USER, $PAGE;
        $systemcontext = context_system::instance();
        $stable = new stdClass();
        $stable->trackid = $trackid;
        $stable->thead = false;
        $stable->start = 0;
        $stable->length = 1;
        $learningtrack = (new learningtracks)->get_listof_learningtracks($stable);
        if(!empty($learningtrack->description)){
            $description = format_text($learningtrack->description);
        }else{
            $description = "";
        }
        $isdescription = '';
        if (empty($description)) {
           $isdescription = false;
        } else {
            $isdescription = true;
        }
        if ($learningtrack->logo > 0) {
            $trackimg = tracklogo_url($learningtrack->logo);
            if($trackimg == false){
                $trackimg = $OUTPUT->image_url('eventsampleimage', 'local_learningtracks');
                $trackimg = $trackimg->out();
            }
        } else {
            $trackimg = $OUTPUT->image_url('eventsampleimage', 'local_learningtracks');
            $trackimg = $trackimg->out();
        }
        $trackimg = $trackimg;
        $stable = new stdClass();
        $stable->trackid = $trackid;
        $stable->thead = false;
        $stable->start = 0;
        $stable->length = 1;
        $trackitems =  (new learningtracks)->get_listof_learningitems($trackid, $stable);
        $learningitems_count = $trackitems['learningitemscount'];
        $trackusers = (new learningtracks)->get_listof_users($trackid, $stable);
        $usercount = $trackusers['userscount'];
        $learningitems =  $trackitems['learningitems'];
        $completed_count = (new learningtracks)->completed_items_count($trackid);
        $edit =  false;
        $action = false;
        $assignusers = false;
        $trackname = $learningtrack->name;
        $assignuser_url = $CFG->wwwroot.'/local/learningtracks/enrollment.php?trackid='.$trackid;
        $tabs = false;
        if ((has_capability('local/learningtracks:managelearningtracks', $systemcontext) || is_siteadmin())) {
            $action = true;
            $coursestab = true;
            $audiencetab = true;
            $tabs = true;
            $user_tab = true;
        }
        if(!is_siteadmin() &&  has_capability('local/organization:manage_organizationofficial', $systemcontext)) {
            $tabs = true;
            $user_tab = true;
            $coursestab = true;
        }
        $learningtrackcontext = [
            'learningtrack' => $learningtrack,
            'trackid' => $trackid,
            'trackname' => $learningtrack->name,
            'description' => $description,
            'isdescription' => $isdescription,
            'edit' => $edit,
            'action' => $action,
            'assignusers' => $assignusers,
            'tabs' => $tabs,
            'course_tab' => $coursestab,
            'user_tab' =>  $user_tab,
            'audience_tab' => $audiencetab,
            'assignuser_url' => $assignuser_url,
            'nolearningitems' => $learningitems_count,
            'usercount' => $usercount,
            'trackimg' => $trackimg,
            'completed_count' => $completed_count
        ];

      if(!is_siteadmin() && has_capability('local/organization:manage_organizationofficial', $systemcontext)) {

            $bookseatsurl = $CFG->wwwroot.'/local/learningtracks/enrollment.php?trackid='.$trackid;


            $learningtrackcontext['bookseats'] = $bookseatsurl;
      

        } 
         //print_object($learningtrackcontext); exit;
        $return = $this->render_from_template('local_learningtracks/learningtracksContent', $learningtrackcontext);
        return $return;
    }

    public function competency_list($data) {
        global $DB, $PAGE, $OUTPUT, $CFG;
        return $this->render_from_template('local_learningtracks/competecylist', $data);
    }

    public function trackview_courses($courses, $trackid) {
        global $OUTPUT, $CFG, $DB,$USER;
        $context = context_system::instance();
        $data = array();
        foreach ($courses as $sdata) {
            $line = array();
            $line['id'] = $sdata->id;
           // $complete = false;
            if ($sdata->itemtype == '1') {
                $itemdata = $DB->get_record('local_trainingprogram',['id' =>  $sdata->itemid]);
                $name = $itemdata->name;
                $description = $itemdata->description;
               // if($DB->record_exists('tp_offerings',array('trainingid'=>$itemdata->id))) {
                $viewurl = $CFG->wwwroot.'/course/view.php?id='.$itemdata->courseid;
                //}
                $item_url =  $CFG->wwwroot.'/local/trainingprogram/programcourseoverview.php?programid='.$itemdata->id; //$viewurl;
                $imageurl = trainingprogramlogo_url($itemdata->image);
                $startdate =  date('d/m/Y',$itemdata->availablefrom);
                $type = get_string('pluginname', 'local_trainingprogram');
                $ownedby = '';
                $usercount = 0;
                $tracklist = $DB->get_records('local_lts_enrolment',['trackid' => $sdata->trackid]);
                if($tracklist) {
                    foreach($tracklist as $track) {
                        $usercount = $DB->count_records('local_lts_item_enrolment',['trackid' => $track->id, 'itemid' => $itemdata->id, 'itemtype' => 1]);
                    }
                }
                $complete_status = (new learningtracks)->trackitem_completion_status($sdata->trackid, $sdata->itemid, 1);
                if($complete_status[$sdata->itemid]->enroluerscount == $complete_status[$sdata->itemid]->compltuerscount) {
                    $complete = true;
                } else {
                    $complete = false;
                }
                $trainingprograms = true;
                $exams = false;
                //$count = $DB->count_records('local_lts_item_enrolment',['itemid' =>  $sdata->itemid, 'itemtype' => $sdata->itemtype]);

            } else if ($sdata->itemtype == '2') {
                $itemdata = $DB->get_record('local_exams',['id' =>  $sdata->itemid]);
                $name = $itemdata->exam;
                $description = $itemdata->programdescription;
                $viewurl = $CFG->wwwroot.'/local/exams/examdetails.php?id='.$sdata->itemid;
                $moduleid = $DB->get_field('modules', 'id', ['name' => 'quiz']);
                $quizid = $DB->get_field('course_modules', 'id', ['course' => $itemdata->courseid, 'module' => $moduleid, 'instance' => $itemdata->quizid]);
                $quizid = !empty($quizid) ? $quizid : 0;
                $item_url = $CFG->wwwroot.'/local/exams/exams_qualification_details.php?id='.$sdata->itemid;//$CFG->wwwroot.'/mod/quiz/view.php?id='.$quizid;
                $startdate =  date('d/m/Y',$itemdata->examdatetime);
                $itemid = $itemdata->learningmaterial;
                $ownedby = $itemdata->ownedby;
                // $imageurl =  examlearningmaterial_url($itemdata->learningmaterial);
                $type = get_string('pluginname', 'local_exams');
                $exams = true;
                $trainingprograms = false;
                $usercount = 0;
                $tracklist = $DB->get_records('local_lts_enrolment',['trackid' => $sdata->trackid]);
                if($tracklist) {
                    foreach($tracklist as $track) {
                        $usercount = $DB->count_records('local_lts_item_enrolment',['trackid' => $track->id, 'itemid' => $itemdata->id, 'itemtype' => 2]);
                    }
                } 
                $complete_status = (new learningtracks)->trackitem_completion_status($sdata->trackid, $sdata->itemid, 2);
                if($complete_status[$sdata->itemid]->enroluerscount == $complete_status[$sdata->itemid]->compltuerscount) {
                    $complete = true;
                } else {
                    $complete = false;
                }
            }
            $coursedata = get_course($itemdata->courseid);
            $courseprogress = new progress();
            $completionstatus = $courseprogress->get_course_progress_percentage($coursedata);
            $line['progress_status'] =  $completionstatus !== null ? round($completionstatus,2) : '0';
            if($imageurl == false){
                $imageurl = $OUTPUT->image_url('eventsampleimage', 'local_learningtracks');
                $imageurl = $imageurl->out();
            }
            
            $isdescription = '';
            if (empty($description)) {
               $isdescription = false;
               $decsriptionstring="";
            } else {
                $isdescription = true;
                if (strlen($description) > 270) {
                    $decsriptionCut = substr($description, 0, 270); 
                    $decsriptionstring =  format_text($decsriptionCut);
                }else{
                     $decsriptionstring="";
                }
            }
            if(has_capability('local/learningtracks:viewusers', context_system::instance()) || is_siteadmin()){
                $is_progressbar =  false;
                $viewdetails = true;
            } else if(!is_siteadmin() && has_capability('local/organization:manage_organizationofficial', context_system::instance())) {
                $is_progressbar =  false;
                //$viewdetails = true;
            } else {
                $courseprogress = new progress();
                $is_progressbar =  true;
                $viewdetails = false;
            }
            //var_dump($sdata); exit;
            $line['name'] = $name;
            $line['description'] = $description;
            $line['descriptionstring'] = $decsriptionstring;
            $line['isdescription'] = $isdescription;
            $line['viewitemurl'] = $viewurl;
            $line['imageurl'] = $imageurl;
            $line['startdate'] = $startdate;
            $line['ownedby'] = $ownedby;
            $line['is_progressbar'] = $is_progressbar;
            $line['viewdetails'] = $viewdetails;
            $line['type'] = $type;
            $line['item_url'] = $item_url;
            $line['itemtype'] = $sdata->itemtype;
            $line['itemid'] = $sdata->itemid;
            $line['trackid'] = $sdata->trackid;
            $line['usercount'] = $usercount;
            $line['exams'] = $exams;
            $line['trainingprograms'] = $trainingprograms;
            $line['complete_status'] = $complete;
            $data[] = $line; 
        }
        return array('data' => $data);
    }

    public function get_learningpath($filter = false) {
        $systemcontext = context_system::instance();
        $options = array('targetID' => 'manage_learningpath','perPage' => 1, 'cardClass' => 'col-md-6 col-12', 'viewType' => 'card');
        $options['methodName'] = 'local_learningtracks_get_learningpath';
        $options['templateName'] = 'local_learningtracks/learning_path';
        $options = json_encode($options);
        $filterdata = json_encode(array());
        $dataoptions = json_encode(array('contextid' => $systemcontext->id));
        $context = [
                'targetID' => 'manage_learningpath',
                'options' => $options,
                'dataoptions' => $dataoptions,
                'filterdata' => $filterdata,
        ];
        if($filter){
            return  $context;
        }else{
            return  $this->render_from_template('theme_academy/cardPaginate', $context);
        }
    }

    public function trackenrollment($from_userstotal, $from_users, $to_userstotal, $to_users, $myJSON, $track_id, $examlist, $roleid) {
        global $DB, $PAGE, $OUTPUT, $CFG;
        //var_dump($from_users); exit;
        echo $this->render_from_template('local_learningtracks/enrollment', array('from_userstotal' => $from_userstotal, 'from_users' => $from_users, 'to_userstotal' => $to_userstotal, 'to_users' => $to_users, 
        'myJSON' => $myJSON, 'track_id' => $track_id, 'examlist' => $examlist, 'roleid' => $roleid));
    }
    public function track_check($id) {
        global $OUTPUT, $CFG, $DB, $USER, $PAGE;
        $stable = new stdClass();
        $stable->trackid = $id;
        $stable->thead = false;
        $stable->start = 0;
        $stable->length = 1;
        $track =  (new learningtracks)->get_listof_learningtracks($stable);
        $context = context_system::instance();
        if (empty($track)) {
            print_error("Data Not Found!", 'error');
        }
        return $track;
    }

    public function trackview_users($users, $trackid) {
        global $OUTPUT, $CFG, $DB,$USER;
        $context = context_system::instance();
        $data = array();
        foreach ($users as $sdata) {
            $line = array();
            $line['id'] = $sdata->id;
            $line['username'] = fullname($sdata);
            $line['email'] = $sdata->email;
            $data[] = $line; 
        }
        return array('data' => $data);
    }

    public function get_learningpath_cardview($filter = false) {
        $systemcontext = context_system::instance();
        $options = array('targetID' => 'viewlearninpathdata','perPage' => 5, 'cardClass' => 'col-md-6 col-12', 'viewType' => 'card');
        $options['methodName'] = 'local_learningtracks_viewlearningpath';
        $options['templateName'] = 'local_learningtracks/learning_path_cards';
        $options = json_encode($options);
        $filterdata = json_encode(array());
        $dataoptions = json_encode(array('contextid' => $systemcontext->id, 'append' => 1));
        $context = [
                'targetID' => 'viewlearninpathdata',
                'options' => $options,
                'dataoptions' => $dataoptions,
                'filterdata' => $filterdata,
        ];
        if($filter) {
            return  $context;
        } else {
            return  $this->render_from_template('theme_academy/cardPaginate', $context);
        }
    }

    public function listoflearningtracks($filterparams) {
        global $DB, $PAGE, $OUTPUT;
        $systemcontext = context_system::instance();
        $filterparams['addaction'] = (is_siteadmin() || has_capability('local/organization:manage_trainingofficial',$systemcontext)) ? true : false;
        echo $this->render_from_template('local_learningtracks/learningtracks_card', $filterparams);
    }

    public function listofcardviewlearningpath($filterparams) {
        global $DB, $PAGE, $OUTPUT;
        echo $this->render_from_template('local_learningtracks/learning_path_list', $filterparams);
    }
    public function global_filter($filterparams) {
        global $DB, $PAGE, $OUTPUT;
        return $this->render_from_template('theme_academy/global_filter', $filterparams);;
    }

    public function learningpath_list($stable, $filterdata) {
        global $USER, $CFG, $DB, $OUTPUT;
        $systemcontext = context_system::instance();
        $gettracks = learningtracks::get_listof_learningtracks($stable, $filterdata);
        $tracks = array_values($gettracks['tracks']);
        $row = array();
        $stable = new \stdClass();
        $stable->thead = true;
        $count = 0;
        foreach ($tracks as $list) {
            $record = array();
            $record['id'] = $list->id;
            $record['name'] = $list->name;
            $record['code'] = $list->code;
            $statusarry = array(0 => 'Pending', 1 => 'Approve', 2 => 'Completed', 3 => 'Rejected');
            $record['status'] = $statusarry[$list->status];
            $stable->trackid = $list->id;
            $stable->start = 0;
            $stable->length = 1;
            $courses =  (new learningtracks)->get_listof_learningitems($list->id, $stable, 1);
            $record['courses_count'] = $courses['learningitemscount'];

            $exams =  (new learningtracks)->get_listof_learningitems($list->id, $stable, 2);
            $record['exams_count'] = $exams['learningitemscount'];

            $trackitems =  (new learningtracks)->get_listof_learningitems($list->id, $stable);
            $learningitems_count = $trackitems['learningitemscount'];
            $trackusers = (new learningtracks)->get_listof_users($list->id, $stable);
            $enrollcount = $trackusers['userscount'];
            $record['nolearningitems'] =  $learningitems_count;
            $record['enrollcount'] =  $enrollcount;
            if(!empty($list->description)){
                $description = format_text($list->description);
            }else{
                $description = "";
            }
            $isdescription = '';
            if (empty($description)) {
               $isdescription = false;
            } else {
                $isdescription = true;
                if (strlen($description) > 200) {
                    $decsriptionCut = substr($description, 0, 200);
                    $descriptionstring =format_text($decsriptionCut);
                }else{
                    $descriptionstring = "";
                }
            }
            $record['description'] =  $description;
            $record['isdescription'] =  $isdescription;
            $record['descriptionstring'] =  $descriptionstring;
            if ($list->logo > 0) {
                $trackimg = tracklogo_url($list->logo);
                if($trackimg == false){
                    $trackimg = $OUTPUT->image_url('eventsampleimage', 'local_learningtracks');
                    $trackimg = $trackimg->out();
                }
            } else {
                $trackimg = $OUTPUT->image_url('eventsampleimage', 'local_learningtracks');
                $trackimg = $trackimg->out();
            }
            $trackimg = $trackimg;
            $record['trackimg'] =  $trackimg;
            $record['count'] = $count+1;
            $count++;
            $row[] = $record;
        }
        return array_values($row);
    }

    public function get_enrolled_learningpath($filter = false) {
        $systemcontext = context_system::instance();
        $options = array('targetID' => 'viewenrollerlp','perPage' => 5, 'cardClass' => 'col-md-6 col-12', 'viewType' => 'card');
        $options['methodName'] = 'local_learningtracks_enrolledlearningpath';
        $options['templateName'] = 'local_learningtracks/mylearningpath_list';
        $options = json_encode($options);
        $filterdata = json_encode(array());
        $dataoptions = json_encode(array('contextid' => $systemcontext->id));
        $context = [
                'targetID' => 'viewenrollerlp',
                'options' => $options,
                'dataoptions' => $dataoptions,
                'filterdata' => $filterdata,
        ];
        if($filter) {
            return  $context;
        } else {
            return  $this->render_from_template('theme_academy/cardPaginate', $context);
        }
    }

    public function get_enrolled_courses($filter = false) {
        $systemcontext = context_system::instance();
        $trackid = optional_param('id', 0, PARAM_INT);
        $options = array('targetID' => 'my_enrolled_courses','perPage' => 5, 'cardClass' => 'col-md-6 col-12', 'viewType' => 'card');
        $options['methodName'] = 'local_learningtracks_trackview_courses';
        $options['templateName'] = 'local_learningtracks/my_enrolled_courses';
        $options['trackid'] = $trackid;
        $options = json_encode($options);
        $filterdata = json_encode(array());
        $dataoptions = json_encode(array('contextid' => $systemcontext->id, 'trackid' => $trackid));
        $context = [
                'targetID' => 'my_enrolled_courses',
                'options' => $options,
                'dataoptions' => $dataoptions,
                'filterdata' => $filterdata,
        ];
        if($filter) {
            return  $context;
        } else {
            return  $this->render_from_template('theme_academy/cardPaginate', $context);
        }
    }


    public function my_learning_tracks($tracks) {
        global $USER, $CFG, $DB;
        $systemcontext = context_system::instance();
        $row = array();
        $stable = new \stdClass();
        $stable->thead = true;
        $stable->userid = $USER->id;
        $count = 0;
        foreach ($tracks as $list) {
            $record = array();
            $record['id'] = $list->id;
            $record['name'] = $list->name;
            $record['code'] = $list->code;
            $statusarry = array(0 => 'Pending', 1 => 'Approve', 2 => 'Completed', 3 => 'Rejected');
            $record['status'] = $statusarry[$list->status];
            $total_courses = (new learningtracks)->get_listof_enrolledcourses($list->id, $USER->id);
            $completed_courses = (new learningtracks)->get_listof_enrolledcourses($list->id, $USER->id, 1);
            $remaining_courses = (new learningtracks)->get_listof_enrolledcourses($list->id, $USER->id, 0);
            $record['enrollcount'] = count($total_courses);
            $record['completed_count'] = count($completed_courses);
            $record['remaining_count'] = count($remaining_courses);
            $record['completedstatus'] = false;
            if(count($total_courses) > 0) {
                if(count($total_courses) == count($completed_courses)) {
                    $record['completedstatus'] = true;
                } else {
                    $record['completedstatus'] = false;
                }
            }
            $stable->trackid = $list->id;
            $stable->start = 0;
            $stable->length = 1;
            $trackitems =  (new learningtracks)->get_listof_learningitems($list->id, $stable);
            $learningitems_count = $trackitems['learningitemscount'];
            $trackusers = (new learningtracks)->get_listof_users($list->id, $stable);
            $enrollcount = $trackusers['userscount'];
            $record['nolearningitems'] =  $learningitems_count;
            $record['enrollcount1'] =  $enrollcount;
            $record['action'] = false;
            $record['delete'] = false;
            $record['edit'] = false;
            $record['view'] = false;
            $record['assignuser'] = false;
            $record['viewurl'] = $CFG->wwwroot."/local/learningtracks/learningpathview.php?id=".$list->id;
            $record['count'] = $count+1;
            $count++;
            $row[] = $record;
         }
        return array_values($row);
    }
    public function get_mytrackview($trackid) {
        global $OUTPUT, $CFG, $DB, $USER, $PAGE;
        $stable = new stdClass();
        $stable->trackid = $trackid;
        $stable->thead = false;
        $stable->start = 0;
        $stable->length = 1;
        $learningtrack = (new learningtracks)->get_listof_learningtracks($stable);
        if(!empty($learningtrack->description)){
            $description = format_text($learningtrack->description);
        }else{
            $description = "";
        }
        $isdescription = '';
        if (empty($description)) {
           $isdescription = false;
        } else {
            $isdescription = true;
        }
        if ($learningtrack->logo > 0) {
            $trackimg = tracklogo_url($learningtrack->logo);
            if($trackimg == false){
                $trackimg = $OUTPUT->image_url('eventsampleimage', 'local_learningtracks');
                $trackimg = $trackimg->out();
            }
        } else {
            $trackimg = $OUTPUT->image_url('eventsampleimage', 'local_learningtracks');
            $trackimg = $trackimg->out();
        }
        $trackimg = $trackimg;
        $total_courses = (new learningtracks)->get_listof_enrolledcourses($trackid, $USER->id);
        $completed_courses = (new learningtracks)->get_listof_enrolledcourses($trackid, $USER->id, 1);
        $remaining_courses = (new learningtracks)->get_listof_enrolledcourses($trackid, $USER->id, 0);
        $trackusers = (new learningtracks)->get_listof_users($trackid, $stable);
        $learning_items = [];
        $stable->search = false;
        $stable->thead = false;
        $stable->start = 0;
        $stable->length = '';
        $courses =  learningtracks::get_listof_learningitems($trackid, $stable);
        if($courses) {
            $i =1;
            foreach($courses['learningitems'] as $item) {
                $count = $i;
                $item_status = (new learningtracks)->get_listof_enrolledcourses($trackid, $USER->id, null, $item->itemid, $item->itemtype);
                if($item_status->status =='1') {
                    $completed = 'completed';
                } else {
                    $completed = '';
                }
                $learning_items[] = ['count' => $count, 'completed' => $completed];
                $i++;
            }
        }
       // var_dump($learning_items); exit;
        $usercount = $trackusers['userscount'];
        $learningtrackcontext = [
            'learningtrack' => $learningtrack,
            'trackid' => $trackid,
            'trackname' => $learningtrack->name,
            'description' => $description,
            'isdescription' => $isdescription,
            'nolearningitems' => count($total_courses),
            'remainingcount' => count($remaining_courses),
            'trackimg' => $trackimg,
            'completed_count' => count($completed_courses),
            'enrolled_users' => $usercount,
            'learning_items' => $learning_items,
            'userid' => $USER->id,
        ];
        $return = $this->render_from_template('local_learningtracks/mylearningtracksContent', $learningtrackcontext);
        return $return;
    }

    public function manage_capability() {
        $systemcontext = context_system::instance();
        if(is_siteadmin() || has_capability('local/learningtracks:managelearningtracks', $systemcontext)  
         || has_capability('local/organization:manage_organizationofficial',$systemcontext) ){
           return true;
        } else {
            print_error(get_string('permissionerror', 'local_learningtracks'));
        }
    }

}
