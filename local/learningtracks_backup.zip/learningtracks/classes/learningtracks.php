<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Class containing helper methods for processing data requests.
 *
 * @package    local_learningtracks
 * @copyright  2022 e abyas  <info@eabyas.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_learningtracks;

use coding_exception;
use context_helper;
use context_system;
use core_user;
use dml_exception;
use moodle_exception;
use moodle_url;
use required_capability_exception;
use stdClass;
use local_exams\local\examms;
use local_trainingprogram\local\trainingprogram;
use local_exams\local\exams;
use tool_product\product as product;

defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot.'/local/notifications/notification.php');

/**
 * Class containing helper methods for processing data requests.
 *
 * @copyright  2018 Jun Pataleta
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class learningtracks {

    public function get_learningtracks_list() {
        global $DB, $PAGE, $OUTPUT;
        $systemcontext = context_system::instance();
        $renderer = $PAGE->get_renderer('local_learningtracks');
        $filterparams  = $renderer->get_content(true);
        $filterparams['submitid'] = 'form#filteringform';
        $filterparams['widthclass'] = 'col-md-6';
        $filterparams['placeholder'] =get_string('search_requested','local_learningtracks');
        $globalinput = $renderer->global_filter($filterparams);
        $learningtracks = $renderer->get_content();
        $filterparams['learningtracks_list'] = $learningtracks;
        $filterparams['globalinput'] = $globalinput;
        $renderer->listoflearningtracks($filterparams);
    }
    public static function get_listof_learningtracks($stable, $filterdata=null) {
        global $DB, $USER;
        $params          = array();
        $tracks      = array();
        $trackscount = 0;
        $concatsql       = '';
        if (isset($stable->trackid) && $stable->trackid > 0) {
            $concatsql .= " AND lt.id = :trackid";
            $params['trackid'] = $stable->trackid;
        }
        /*if(isset($filterdata->status) && $filterdata->status=='0'){
            $concatsql .= " AND date(FROM_UNIXTIME(e.enddate)) >= CURDATE()";
        }
        if($filterdata->status=='1'){
            $concatsql .= " AND date(FROM_UNIXTIME(e.enddate)) < CURDATE()";
        }*/

        if  (isset($filterdata->search_query) && trim($filterdata->search_query) != ''){
            $concatsql .= " AND (lt.name LIKE :firstnamesearch) ";
            $params = array('firstnamesearch' => '%'.trim($filterdata->search_query).'%');
        }
        $countsql = "SELECT COUNT(lt.id) ";
        $fromsql = "SELECT lt.* ";
        $sql = " FROM {local_learningtracks} AS lt
                WHERE lt.id > 0 ";
        if (!empty($filterdata->search_query)) {
            $concatsql .= " AND lt.name  LIKE '%" . trim($filterdata->search_query) . "%' ";
        }
        $sql .= $concatsql;
        if (isset($stable->trackid) && $stable->trackid > 0) {
            $tracks = $DB->get_record_sql($fromsql . $sql, $params);
        } else {
            try {
                $trackscount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY lt.id DESC";
                    $tracks = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $trackscount = 0;
            }
        }
        if (isset($stable->trackid) && $stable->trackid > 0) {
            return $tracks;
        } else {
            return compact('tracks', 'trackscount');
        }
    }

    public function get_organizationslist($query = null) {
        global $DB;
        $fields = array('lo.fullname', 'lo.shortname');
        $likesql = array();
        $i = 0;
        foreach ($fields as $field) {
            $i++;
            $likesql[] = $DB->sql_like($field, ":queryparam$i", false);
            $sqlparams["queryparam$i"] = "%$query%";
        }
        $sqlfields = implode(" OR ", $likesql);
        $concatsql = " AND ($sqlfields) ";
        $allobject[] = new \stdClass();
        $allobject[0]->id = 0;
        $allobject[0]->fullname = get_string('all', 'local_learningtracks');
        $allobjectarr = array('id' => 0 , 'fullname'=> get_string('all', 'local_learningtracks'));
        $sql = "SELECT lo.id AS id, CONCAT(lo.fullname, ' ', lo.shortname) AS fullname FROM {local_organization} lo WHERE 1 = 1 $concatsql";
        $sqldata = $DB->get_records_sql($sql, $sqlparams);
        $data = array_merge($allobject,$sqldata);
        $list = array_values(json_decode(json_encode(($data)), true));
        return $list;
    }

    public function get_competencylist($query = null) {
        global $DB;
        $fields = array('lc.name', 'lc.code');
        $likesql = array();
        $i = 0;
        foreach ($fields as $field) {
            $i++;
            $likesql[] = $DB->sql_like($field, ":queryparam$i", false);
            $sqlparams["queryparam$i"] = "%$query%";
        }
        $sqlfields = implode(" OR ", $likesql);
        $concatsql = " AND ($sqlfields) ";
        $data = $DB->get_records_sql("SELECT lc.id, CONCAT(lc.name, ' ', lc.code) AS fullname FROM {local_competencies} lc WHERE 1=1 $concatsql", $sqlparams);
        return $data;
    }

    public function get_examlist($trackid, $query = null) {
        global $DB;
        $fields = array('le.exam', 'le.code');
        $likesql = array();
        $i = 0;
        foreach ($fields as $field) {
            $i++;
            $likesql[] = $DB->sql_like($field, ":queryparam$i", false);
            $sqlparams["queryparam$i"] = "%$query%";
        }
        $sqlfields = implode(" OR ", $likesql);
        $concatsql = " AND ($sqlfields) ";
        if($trackid) {
            $sql = "SELECT le.id AS id, CONCAT(le.exam, ' ', le.code) AS fullname FROM {local_exams} le
            WHERE le.id NOT IN (SELECT li.itemid FROM {local_learning_items} li
            WHERE li.itemid = le.id AND li.itemtype = 2 AND li.trackid = $trackid) $concatsql";
        } else {
            $sql = "SELECT le.id AS id, CONCAT(le.exam, ' ', le.code) AS fullname FROM {local_exams} le
            WHERE le.status=1 $concatsql";  
        }
        $data = $DB->get_records_sql($sql, $sqlparams);
        return $data;
    }

    public function get_programlistt($trackid, $query = null) {
        global $DB;
        $fields = array('lp.name', 'lp.code');
        $likesql = array();
        $i = 0;
        foreach ($fields as $field) {
            $i++;
            $likesql[] = $DB->sql_like($field, ":queryparam$i", false);
            $sqlparams["queryparam$i"] = "%$query%";
        }
        $sqlfields = implode(" OR ", $likesql);
        $concatsql = " AND ($sqlfields) ";
        if($trackid) {
            $sql = " SELECT lp.id AS id, CONCAT(lp.name, ' ', lp.code) AS fullname FROM {local_trainingprogram} lp
            JOIN {tp_offerings} tpo ON lp.id = tpo.trainingid
            WHERE lp.id NOT IN (SELECT li.itemid FROM {local_learning_items} li
            WHERE li.itemid = lp.id AND li.itemtype = 1 AND li.trackid = $trackid) AND tpo.type = 2 $concatsql";
        } else {
            $sql = " SELECT lp.id AS id, CONCAT(lp.name, ' ', lp.code) AS fullname FROM {local_trainingprogram} lp
            JOIN {tp_offerings} tpo ON lp.id = tpo.trainingid AND tpo.type = 2 $concatsql";
        }
        $data = $DB->get_records_sql($sql, $sqlparams);
        return $data;
    }

    public function add_update_track($data) {
        global $DB,$USER,$CFG;
		$systemcontext = context_system::instance();
        if(isset($data->description)) {
           $data->description =  $data->description['text'];
        }
        if (isset($data->logo)) {
			$data->logo = $data->logo;
			file_save_draft_area_files($data->logo, $systemcontext->id, 'local_learningtracks', 'logos', $data->logo);
		}
        $data->points = 0;
        $data->tags = 0;
        $data->competency = implode(',', $data->competency);
		if ($data->id) {
            $data->timemodified = time();
			$DB->update_record('local_learningtracks', $data);
            // Trigger learning track updated.
            $eventparams = array('context' => context_system::instance(),'objectid'=>$data->id);
            $event = event\learning_track_updated::create($eventparams);
            $event->trigger();
             // notification learningtrack update
            $trackinfo = $DB->get_record('local_learningtracks', array('id' => $data->id));
             $row=[];
             $row['learningTrackName']=$trackinfo->name;
             $row['updated']='updated';
            $myobject=(new \local_learningtracks\notification);
            $myobject->learningtracks_notification('learningtrack_update',$touser=null, $USER,$row,$waitinglistid=0);
            // notification learningtrack onchange
            $sql="SELECT u.* FROM {user} u
				 JOIN {local_lts_enrolment} le ON le.userid = u.id
                 WHERE le.trackid = $data->id AND u.confirmed = 1 AND u.suspended = 0 AND u.deleted = 0 AND u.id > 2";
                  $touser = $DB->get_records_sql($sql);
            $thispageurl = new moodle_url('/local/learningtracks/view.php?id='.$data->id);
             $row1=[];
             $row1['RelatedModuleName']=$trackinfo->name;
             $row1['RelatedModulesLink']=$thispageurl;
            $myobject=(new \local_learningtracks\notification);
            $myobject->learningtracks_notification('learningtrack_onchange',$touser, $USER,$row1,$waitinglistid=0);
			//------------------------------------------------------
            return $data->id;
		} else {
            $data->status = 0;
            $data->timecreated = time();
            $id=$DB->insert_record('local_learningtracks', $data);
            // Trigger learning track added.
            $eventparams = array('context' => context_system::instance(),'objectid'=>$id);
            $event = event\learning_track_added::create($eventparams);
            $event->trigger();
           // notification learningtrack add
            $trackinfo = $DB->get_record('local_learningtracks', array('id' => $id));
            $row=[];
            $row['learningTrackName']=$trackinfo->name;
            $row['created']='created';
            $myobject=(new \local_learningtracks\notification);
            $myobject->learningtracks_notification('learningtrack_create',$touser=null,$USER,$row,$waitinglistid=0);
            return $id;
		}
    }

    public function set_data($id) {
    	global $DB;
        $data = $DB->get_record('local_learningtracks', ['id' => $id], '*', MUST_EXIST);
		$row['id'] = $data->id;
		$row['name'] = $data->name;
		$row['code'] = $data->code;
		$row['organization'] = $data->organization;
		$row['competency'] = explode(',', $data->competency);
		$row['logo'] = $data->logo;
		$row['requiredsequence'] = $data->requiredsequence;
		$row['description'] = ['text' => $data->description];
        $row['points'] = $data->points;
		$row['tags'] = $data->tags;
        $row['requiredapproval'] = $data->requiredapproval;
        return $row;
    }

    public function competency_list($stable, $filterdata) {
        global $DB, $PAGE;
        $systemcontext = context_system::instance();
        $formsql       = '';
        $competencies =  $DB->get_field('local_learningtracks', 'competency', ['id' => $filterdata->trackid]);
        $selectsql = "SELECT le.* "; 
        $countsql  = "SELECT COUNT(le.id) ";
        $sql = " FROM {local_competencies} le WHERE 1=1 AND id IN ($competencies)";
        if (isset($filterdata->search_query) && trim($filterdata->search_query) != '') {
            $formsql .= " AND le.name LIKE :search";
            $searchparams = array('search' => '%'.trim($filterdata->search_query).'%');
        } else {
            $searchparams = array();
        }     
        $params = array_merge($searchparams);
        $sql .= $formsql;
        $totalcompetency = $DB->count_records_sql($countsql.$sql, $params);
        $formsql .=" ORDER BY le.id DESC";
        $addedcompetencies = $DB->get_records_sql($selectsql.$sql, $params, $stable->start,$stable->length);
        if ($addedcompetencies) {
            $nodata = true;
        } else {
            $nodata = false;
        }
        $competencyContext = array(
            "acompetencies" => $addedcompetencies,
            "nodata" => $nodata,
            "totalcount" => $totalcompetency,
            "length" => $totalcompetency
        );        
        return $competencyContext;
    }

    public function add_learning_items($data) {
        global $DB,$USER,$CFG;
        if ($data->itemtype == 1) {
            $itemids = $data->program;
        } else {
            $itemids = $data->exam;
        }
        
        if($data->id > 0) { 
            $data->timemodified = time();
             // notification learningtrack onchange
        $sql="SELECT u.* FROM {user} u
				 JOIN {local_lts_enrolment} le ON le.userid = u.id
                 WHERE le.trackid = $data->id AND u.confirmed = 1 AND u.suspended = 0 AND u.deleted = 0 AND u.id > 2";
        $touser = $DB->get_records_sql($sql);
        $thispageurl = new moodle_url('/local/learningtracks/view.php?id='.$data->id);
        $trackinfo = $DB->get_record('local_learningtracks', array('id' => $data->id));
        $row1=[];
        $row1['RelatedModuleName']=$trackinfo->name;
        $row1['RelatedModulesLink']=$thispageurl;
        $myobject=(new \local_learningtracks\notification);
        $myobject->learningtracks_notification('learningtrack_onchange',$touser, $USER,$row1,$waitinglistid=0);

            return $DB->update_record('local_learning_items', $data);
        } else {
            foreach($itemids as $ids) {
                $data->itemid = $ids;
                $data->timecreated = time();
               // $DB->insert_record('local_learning_items', $data);
                $id=$DB->insert_record('local_learning_items', $data);
                 // notification learningtrack onchange
                 $sql="SELECT u.* FROM {user} u
				 JOIN {local_lts_enrolment} le ON le.userid = u.id
                 WHERE le.trackid = $data->trackid AND u.confirmed = 1 AND u.suspended = 0 AND u.deleted = 0 AND u.id > 2";
                  $touser = $DB->get_records_sql($sql);
                 $thispageurl = new moodle_url('/local/learningtracks/view.php?id='.$data->trackid);
                $trackinfo = $DB->get_record('local_learningtracks', array('id' => $data->trackid));
                $row1=[];
                $row1['RelatedModuleName']=$trackinfo->name;
                $row1['RelatedModulesLink']=$thispageurl;
                $myobject=(new \local_learningtracks\notification);
                $myobject->learningtracks_notification('learningtrack_onchange',$touser, $USER,$row1,$waitinglistid=0);
                    // Trigger learning items to track.
                $eventparams = array('context' => context_system::instance(),'objectid'=>$id);
                $event = event\add_items_totrack::create($eventparams);
                $event->trigger();
            } 
        }
    }

    public static function get_listof_learningitems($trackid, $stable, $itemtype = '') {
        global $DB, $USER;
        $systemcontext = context_system::instance();
        $params           = array();
        $learningitems = array();
        $concatsql        = '';
        $countsql = "SELECT COUNT(li.id) ";
        $fromsql  = "SELECT li.*";
        $sql      = " FROM {local_learning_items} AS li
                      JOIN {local_learningtracks} AS lt ON li.trackid = lt.id ";
        if(!is_siteadmin() && has_capability('local/organization:manage_trainee', $systemcontext)) {
            $sql .= " JOIN {local_lts_item_enrolment} lie ON lie.itemid = li.itemid ";
        }
        $sql .= "  WHERE li.trackid = :trackid ";
        if($itemtype) {
            $sql .= " AND li.itemtype = $itemtype"; 
        } 
        if($stable->userid) {
            $sql .= " AND lie.userid = $stable->userid"; 
        }
        //echo $fromsql.$sql; exit;
        $params['trackid'] = $trackid;
        $sql .= $concatsql;
        try {
            $learningitemscount = $DB->count_records_sql($countsql . $sql, $params);
            if ($stable->thead == false) {
                $sql .= " ORDER BY li.id DESC";
                $learningitems = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
            }
        }
        catch (dml_exception $ex) {
            $learningitemscount = 0;
        }
        return compact('learningitems', 'learningitemscount');
    }

    public static function get_listof_users($trackid, $stable) {
        global $DB, $USER;
        $context = context_system::instance();
        $params           = array();
        $users = array();
        $concatsql        = '';
        $countsql = "SELECT COUNT(u.id) ";
        $fromsql  = "SELECT u.* ";
        $sql      = " FROM {user} u
				 JOIN {local_lts_enrolment} le ON le.userid = u.id ";
        if(!is_siteadmin() && has_capability('local/organization:manage_organizationofficial',$context)) {
            $organization = $DB->get_field('local_users','organization',array('userid'=>$USER->id));
            $sql .=  " JOIN {local_users} lu ON a.userid = lu.userid";
            $sql.= " AND lu.organization = $organization";
        } 
        $sql .= "  WHERE le.trackid = :trackid AND u.confirmed = 1 AND u.suspended = 0 AND u.deleted = 0 AND u.id > 2 ";
        $sql .= $concatsql;
        $params['trackid'] = $trackid;
        $sql .= $concatsql;
        try {
            $userscount = $DB->count_records_sql($countsql . $sql, $params);
            // if ($stable->thead == false) {
                $sql .= " ORDER BY u.id ASC";
                $users = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
            // }
        }
        catch (dml_exception $ex) {
            $userscount = 0;
        }
        return compact('users', 'userscount');
    }

    public static function get_listof_learningpath($stable, $filterdata) {
        global $CFG,$DB,$OUTPUT,$USER,$PAGE;
        $context = context_system::instance();
        $formsql = '';
        $selectsql = "SELECT lt.id, lt.name, lt.* FROM {local_learningtracks} AS lt ";
        $countsql = "SELECT count(lt.id) FROM {local_learningtracks} AS lt ";   
        if (isset($filterdata->search_query) && trim($filterdata->search_query) != '') {
             $formsql .= " WHERE  lt.name LIKE :search";
             $searchparams = array('search' => '%'.trim($filterdata->search_query).'%');
        } else {
             $searchparams = array();
        }
        $params = array_merge($searchparams);
        $totallearningpath= $DB->count_records_sql($countsql.$formsql, $params);
        $formsql .=" ORDER BY lt.id DESC";
        $learningpath = $DB->get_records_sql($selectsql.$formsql, $params, $stable->start,$stable->length);
        $learningpathlist = array();
        $count = 0;
        foreach ($learningpath as $learningpaths) {
            $learningpathlist[$count]["id"] = $learningpaths->id;  
            $learningpathlist[$count]["name"] = $learningpaths->name;
            $learningpathlist[$count]["description"] = $learningpaths->description;
            $itemid = $learningpaths->logo;
            $fs = get_file_storage();
            $files = $fs->get_area_files($context->id, 'local_learningtracks', 'logos', $itemid);
            foreach($files as $file){
               $url = moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), $file->get_filearea(),
               $file->get_itemid(), $file->get_filepath(), $file->get_filename(), false);
               $download_url = $url->get_port() ? $url->get_scheme() . '://' . $url->get_host() . $url->get_path() . ':' . $url->get_port() : $url->get_scheme() . '://' . $url->get_host() . $url->get_path();
               $learningpaths->logo = $download_url;
            }
            $learningpathlist[$count]["course"] = [];
            $learningpathlist [$count]["logo"] = $learningpaths->logo;
            $totallearningitems=$DB->get_records('local_learning_items',array('trackid'=>$learningpaths->id));
            foreach($totallearningitems as $totallearningitem){
                $coursecount=count($totallearningitem->id);
                if($totallearningitem->itemtype=="2"){
                    $exams=$DB->get_records('local_exams',array('id'=>$totallearningitem->itemid));
                    foreach($exams as $exam){
                        $itemid = $exam->learningmaterial;
                        $fs = get_file_storage();
                        $files = $fs->get_area_files($context->id, 'local_exams', 'learningmaterials', $itemid);
                        foreach($files as $file){
                           $url = moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), $file->get_filearea(),
                           $file->get_itemid(), $file->get_filepath(), $file->get_filename(), false);
                           $download_url = $url->get_port() ? $url->get_scheme() . '://' . $url->get_host() . $url->get_path() . ':' . $url->get_port() : $url->get_scheme() . '://' . $url->get_host() . $url->get_path();                        
                           $exam->learningmaterial = $download_url ;
                        }
                        $learningpathlist[$count]["course"][] = ['name' => $exam->exam,'description'=>$exam->programdescription,'image'=>$exam->learningmaterial,'coursecount'=>$coursecount,'code'=>$exam->code];
                    }                   
                   
                } else if($totallearningitem->itemtype=="1"){
                    $trainingprograms=$DB->get_records('local_trainingprogram',array('id'=>$totallearningitem->itemid));
                    foreach($trainingprograms as $trainingprogram){
                        $itemid = $trainingprogram->image;
                        $fs = get_file_storage();
                        $files = $fs->get_area_files($context->id, 'local_trainingprogram', 'trainingprogramlogo', $itemid);
                        foreach($files as $file){
                        $url = moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), $file->get_filearea(),
                        $file->get_itemid(), $file->get_filepath(), $file->get_filename(), false);
                        $download_url = $url->get_port() ? $url->get_scheme() . '://' . $url->get_host() . $url->get_path() . ':' . $url->get_port() : $url->get_scheme() . '://' . $url->get_host() . $url->get_path();
                        $trainingprogram->image= $download_url ;
                        }
                        $learningpathlist[$count]["course"][] = ['name' => $trainingprogram->name,'description'=>$trainingprogram->description,'image'=>$trainingprogram->image,'coursecount'=>$coursecount,'code'=>$trainingprogram->code];  
                    }
                }
            }
            $count++;
        }
        $nocourse = false;
        $coursesContext = array(
            "hascourses" => $learningpathlist,
            "nocourses" => $nocourse,     
            "totallearningpath" => $totallearningpath,
            "length" => count($learningpathlist)
            );
        return $coursesContext;
    }

    public static function learningtrack_enrolled_users($trackid, $params, $lastitem=0) {
        global $DB, $USER;
        $systemcontext = context_system::instance();
        $traineerole = $DB->get_field('role', 'id', array('shortname' => 'trainee'));
        $fromsql = "SELECT distinct u.id,concat(u.firstname,' ',u.lastname,' ','(',u.email,')') as fullname";
        $countsql = "SELECT count(u.id) as total";
        $sql = " FROM {user} AS u 
                JOIN {local_users} lc ON lc.userid = u.id
                WHERE  u.id > 2 AND u.deleted = 0  AND lc.deleted=0 AND lc.approvedstatus=2";
        if(!is_siteadmin() && has_capability('local/organization:manage_organizationofficial',$systemcontext)) {
            $organization = $DB->get_field('local_users','organization',array('userid'=>$USER->id));
            $sql.= " AND lc.organization = $organization";
        }        
        if($lastitem!=0){
            $sql.=" AND u.id > $lastitem";
        }
        $sql .=" AND u.id <> $USER->id";
        if (!empty($params['query'])) {
            $sql .= " AND ((u.firstname LIKE :firstnamesearch OR u.lastname LIKE :lastnamesearch) OR u.email LIKE :email) ";
            $searchparams = array('firstnamesearch' => '%'.trim($params['query']).'%','lastnamesearch' => '%'.trim($params['query']).'%', 'email' => '%'.trim($params['query']).'%',);
        }  else {
            $searchparams = array();
        }
        if (!empty($params['email'])) {
             $sql.=" AND u.id IN ({$params['email']})";
        }

        $order = ' ORDER BY u.id ASC ';
        $sql .= " AND u.id IN (SELECT roa.userid 
                                          FROM {role_assignments}  roa 
                                         WHERE roa.roleid=:roleid1) ";
        $existingsql = " SELECT le.userid 
                             FROM {local_lts_enrolment} AS le 
                            WHERE  le.trackid =:trackid";

        $availablesql .= " AND u.id NOT IN ($existingsql)";

        $params = array_merge(['trackid' => $trackid, 'roleid1' => $traineerole], $searchparams);
        $ausers = $DB->get_records_sql($fromsql . $sql . $availablesql .$order,$params);

        foreach($ausers as $auser){
            $availableusers[] = ['id' => $auser->id, 'fullname' => $auser->fullname];
        };

        $enrolledsql  .= " AND u.id IN ($existingsql)";
      // var_dump($fromsql . $sql. $enrolledsql .$order,$params); exit;
        $eusers = $DB->get_records_sql($fromsql . $sql. $enrolledsql .$order,$params);
        foreach($eusers as $euser){
            $enrolledusers[] = ['id' => $euser->id, 
                                'fullname' => $euser->fullname];
        };

        $enrolleduserscount = $DB->count_records_sql($countsql . $sql . $availablesql,$params);
        $availableuserscount = $DB->count_records_sql($countsql . $sql . $enrolledsql,$params);

        return compact('availableusers', 'enrolledusers', 'availableuserscount', 'enrolleduserscount');
    }

   /* public static function learningtrack_enrolled_users($type = null, $trackid=0, $params, $total=0, $offset1=-1, $perpage=-1, $lastitem=0) {
        global $DB, $USER;
        
        $context = context_system::instance();
        $traineerole= $DB->get_field('role', 'id', array('shortname' => 'trainee'));
        if($total == 0){
             $sql = "SELECT DISTINCT(u.id), concat(u.firstname,' ',u.lastname,' ','(',u.email,')') as fullname";
        }else{
            $sql = "SELECT COUNT(DISTINCT(u.id)) as total";
        }
        $sql.= " FROM {user} AS u 
                JOIN {local_users} lc ON lc.userid = u.id
                JOIN {role_assignments} AS roa ON roa.userid = u.id
                WHERE  u.id > 2 AND u.deleted = 0  AND lc.deleted=0 AND lc.approvedstatus=2 
                AND roa.roleid = $traineerole";
        if($lastitem!=0){
           $sql.=" AND u.id > $lastitem";
        }
        $sql .=" AND u.id <> $USER->id";
        if (!empty($params['query'])) {
            $sql .= " AND (u.firstname LIKE :firstnamesearch) ";
            $searchparams = array('firstnamesearch' => '%'.trim($params['query']).'%');
        }  else {
            $searchparams = array();
        }
        if (!empty($params['email'])) {
             $sql.=" AND u.id IN ({$params['email']})";
        }
        if ($type=='add') {
            $sql .= " AND u.id NOT IN (SELECT le.userid
                                        FROM {local_lts_enrolment} AS le 
                                        WHERE le.trackid = $trackid)";
                                       // var_dump($sql); exit;
        } elseif ($type=='remove') {
            $sql .= " AND u.id IN (SELECT le.userid
                                 FROM {local_lts_enrolment} AS le 
                                 WHERE le.trackid = $trackid)";
        }

     
        $order = ' ORDER BY u.id ASC ';
        if ($perpage!=-1){
            $limitnumber = $perpage;
        } else{
            $limitnumber = 0;
        }
        //var_dump($sql.$order);  exit;
        $params = array_merge($searchparams);
        if ($total == 0){
            $availableusers = $DB->get_records_sql_menu($sql.$order,$params, 0, $limitnumber);
        } else {
            $availableusers = $DB->count_records_sql($sql,$params);
        }
  
        return $availableusers;
    }*/

    public function learningtrack_enrollmet($trackid, $userid, $roleid, $examlist, $programlist) {
        global $DB,$USER;


            $learning_track = $DB->get_record('local_learningtracks', array('id' => $trackid));
            $learning_items = $DB->get_records('local_learning_items', array('trackid' => $trackid));
            $row = array();
            $row['trackid'] = $trackid;
            $row['userid'] = $userid;
            $row['status'] = 0;
            $row['enrolmentdate'] = time();
            $row['timecreated'] = time();
            $row['usercreated'] = $USER->id; 
          try {
            $record = $DB->insert_record('local_lts_enrolment', $row);
            // notification
            $touser = $DB->get_record('user', array('id' => $userid));
            $row=[];
            $row['learningTrackName']=$learning_track->name;
            $myobject=(new \local_learningtracks\notification);
            $myobject->learningtracks_notification('learningtrack_enroll',$touser, $USER,$row,$waitinglistid=0);
           //----------------------------------------------------------------
 
           if(!empty($examlist)) {
             
                foreach($examlist as $item) {

                    if($this->is_enrolled($item, PRODUCT::EXAMS, $userid)){
                        continue;
                    }
                  
                    $reservationid = $DB->get_field('tool_products', 'referenceid', ['id' => $item, 'category' => product::EXAMS]);
                    
                    (new \local_exams\local\exams)->exam_enrollmet($reservationid, $userid);
                    
                    $lts_item = [];
                    $lts_item['trackid'] = $record;
                    $lts_item['itemid'] = $reservationid;
                    $lts_item['itemtype'] = product::EXAMS;
                    $lts_item['userid'] = $userid;
                    $lts_item['usercreated'] = $USER->id;
                    $lts_item['timecreated'] = time();
                    $lts_item['enrolmentdate'] = time();

                    $DB->insert_record('local_lts_item_enrolment', $lts_item);
                }
            }
            if(!empty($programlist)) {
            
                foreach($programlist as $item) {
                    if($this->is_enrolled($item, PRODUCT::TRAINING_PROGRAM, $userid)){
                        continue;
                    }
                    $offeringid = $DB->get_field('tool_products', 'referenceid', ['id' => $item, 'category' => product::TRAINING_PROGRAM]);
                    (new \local_trainingprogram\local\trainingprogram)->program_enrollment($offeringid,$userid);
                    print_r($offeringid);
                    $lts_item = [];
                    $lts_item['trackid'] = $record;
                    $lts_item['itemid'] = $offeringid;
                    $lts_item['itemtype'] = product::TRAINING_PROGRAM;
                    $lts_item['userid'] = $userid;
                    $lts_item['usercreated'] = $USER->id;
                    $lts_item['timecreated'] = time();
                    $lts_item['enrolmentdate'] = time();
                    $DB->insert_record('local_lts_item_enrolment', $lts_item);
                }
            }
            } catch (dml_exception $ex) {
                print_error($ex);
            }
                // return $record;
            
        }

    public function program_enrolment($programid, $offeringid, $roleid, $userid) {
        global $DB,$USER;
        $program = $DB->get_record('local_trainingprogram', ['id' => $programid]);
      
        $programexist = $DB->record_exists('program_enrollments', ['programid' => $program->id, 'courseid' => $program->courseid, 'userid' => $userid]);
        if (!$programexist) {
            $course = $DB->get_record('course',['id' => $program->courseid], '*', MUST_EXIST);
            $timestart = $course->startdate;
            $timeend = 0;
            if ($timestart == ''){
                $timestart = 0;
            }
            $manual = enrol_get_plugin('manual');
           
            $instance = $DB->get_record('enrol', array('courseid' => $program->courseid, 'enrol' => 'manual'), '*', MUST_EXIST);
            $manual->enrol_user($instance, $userid, $roleid, $timestart, $timeend);
            (new \local_trainingprogram\local\trainingprogram)->program_enrollment($offeringid,$userid,$roleid);
        }
    }

    public function exam_enrolment($examid, $roleid, $userid, $hallid, $examdate) {
        global $DB;
        $exam = $DB->get_record('local_exams', ['id' => $examid]);
        $examexist = $DB->record_exists('exam_enrollments',['examid' => $exam->id, 'courseid' => $exam->courseid, 'userid' => $userid]);
        if (!$examexist) {
            $course = $DB->get_record('course', ['id' => $exam->courseid], '*', MUST_EXIST);
            $timestart = $course->startdate;
            $timeend = 0;
            if ($timestart == ''){
                $timestart = 0;
            }
            $manual = enrol_get_plugin('manual');
            $roleid = $roleid;
            $instance = $DB->get_record('enrol', array('courseid' => $exam->courseid, 'enrol' => 'manual'), '*', MUST_EXIST);
            $manual->enrol_user($instance, $userid, $roleid, $timestart,$timeend);
            (new \local_exams\local\exams)->exam_enrollmet($exam->id, $exam->courseid, $userid, $hallid, $examdate);
        }
    }

    public function learningtrack_unenrollmet($trackid, $userid, $roleid, $examlist, $programlist) {
        global $DB,$USER;
        //$track_records = $DB->get_records('local_lts_enrolment',['trackid' => $trackid, 'userid' => $userid]);
        $examlist = $DB->get_fieldset_select('local_lts_item_enrolment', 'itemid', '',array('trackid' => $trackid, 'itemtype' => product::EXAMS));
        $programlist = $DB->get_fieldset_select('local_lts_item_enrolment', 'itemid','', array('trackid' => $trackid, 'itemtype' => product::TRAINING_PROGRAM));


        if(!empty($programlist)) {
            list($programsql, $programparams) = $DB->get_in_or_equal($programlist);
    
            $sql = "SELECT tpo.id,tpo.trainingid,tpo.startdate FROM {tp_offerings} AS tpo 
            WHERE tpo.id {$programsql}";
    
            $program_list = $DB->get_records_sql($sql, $programparams);
        
            foreach($program_list as $item) {
     
                 (new \local_trainingprogram\local\trainingprogram)->unassignuser($item->trainingid,$item->id,$userid,$roleid);
                $DB->delete_records('local_lts_item_enrolment',['itemid' => $item->trainingid, 'userid' => $userid]);
            }
        }
        if(!empty($examlist)) {
            list($examsql, $examparams) = $DB->get_in_or_equal($examlist);
            $sql = "SELECT  hr.id, hr.typeid, hr.examdate, hr.type, hr.hallid FROM {hall_reservations} hr WHERE hr.type = 'exam' AND
            hr.id {$examsql}";
            $exams_list = $DB->get_records_sql($sql, $examparams);
      
            foreach($exams_list as $item) {
                (new \local_exams\local\exams)->exam_unenrollmet($item->id, $userid);
                $DB->delete_records('local_lts_item_enrolment',['itemid' => $item->typeid, 'userid' => $userid]);
            }
        }

      
        $DB->delete_records('local_lts_enrolment',array('trackid' => $trackid, 'userid' => $userid));
    }

    public function program_unenrol($programid, $offeringid, $userid, $roleid) {
        global $DB,$USER;
        $program = $DB->get_record('local_trainingprogram', ['id' => $programid]);
        $programexist = $DB->record_exists('program_enrollments', ['programid' => $program->id, 'courseid' => $program->courseid, 'userid' => $userid]);
        if ($programexist) {
            $course = $DB->get_record('course',['id' => $program->courseid], '*', MUST_EXIST);
            $manual = enrol_get_plugin('manual');
            $instance = $DB->get_record('enrol', array('courseid' => $program->courseid, 'enrol' => 'manual'), '*', MUST_EXIST);
            $manual->unenrol_user($instance, $userid);
            (new \local_trainingprogram\local\trainingprogram)->program_unenrollment($program->id, $offeringid, $program->courseid, $userid, $roleid);
        }
    }

    public function exam_unenrol($examid, $userid, $roleid) {
        global $DB;
        $exam = $DB->get_record('local_exams', ['id' => $examid]);
        $examexist = $DB->record_exists('exam_enrollments',['examid' => $exam->id, 'courseid' => $exam->courseid, 'userid' => $userid]);
        if ($examexist) {
            $course = $DB->get_record('course', ['id' => $exam->courseid], '*', MUST_EXIST);
            $manual = enrol_get_plugin('manual');
            $instance = $DB->get_record('enrol', array('courseid' => $exam->courseid, 'enrol' => 'manual'), '*', MUST_EXIST);
            $manual->unenrol_user($instance, $userid);
            (new \local_exams\local\exams)->exam_unenrollmet($exam->id, $exam->courseid, $userid);
        }       
    }

    public function get_learningpath_list() {
        global $DB, $PAGE, $OUTPUT;
        $systemcontext = context_system::instance();
        $renderer = $PAGE->get_renderer('local_learningtracks');
        $filterparams  = $renderer->get_learningpath_cardview(true);
        $filterparams['submitid'] = 'form#filteringform';
        $learningpath_programs = $renderer->get_learningpath_cardview();
        $filterparams['learningpath_programs_cards'] = $learningpath_programs;
        $filterparams['inputclasses'] = 'form-control learningpathsearchinput';
        $filterparams['widthclass'] = 'col-md-12';
        $filterparams['placeholder'] =  get_string('search_skill','local_exams');
        $filterparams['filterinput'] = $renderer->global_filter($filterparams);
        $renderer->listofcardviewlearningpath($filterparams);
    }

    public static function get_enrolled_learningpath($stable, $filterdata) {
        global $DB, $USER;
        $params          = array();
        $tracks      = array();
        $trackscount = 0;
        $concatsql       = '';
        if (isset($stable->trackid) && $stable->trackid > 0) {
            $concatsql .= " AND lt.id = :trackid";
            $params['trackid'] = $stable->trackid;
        }
        $countsql = " SELECT COUNT(lt.id) ";
        $fromsql = " SELECT lt.* ";
        $sql = " FROM {local_lts_enrolment} le";
        $sql .= " JOIN {local_learningtracks} lt ON lt.id = le.trackid WHERE le.userid = $USER->id ";
        $sql .= $concatsql;
        if (isset($stable->trackid) && $stable->trackid > 0) {
            $tracks = $DB->get_record_sql($fromsql . $sql, $params);
        } else {
            try {
                $trackscount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY lt.id DESC";
                    $tracks = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $trackscount = 0;
            }
        }
        if (isset($stable->trackid) && $stable->trackid > 0) {
            return $tracks;
        } else {
            return compact('tracks', 'trackscount');
        }
    }

    public function update_competency($data) {
        global $DB,$USER,$CFG;
        $row['id'] = $data->id;
        $row['competency'] = implode(',', $data->competency);
        // notification learningtrack onchange
        $sql="SELECT u.* FROM {user} u
				 JOIN {local_lts_enrolment} le ON le.userid = u.id
                 WHERE le.trackid = $data->id AND u.confirmed = 1 AND u.suspended = 0 AND u.deleted = 0 AND u.id > 2";
                  $touser = $DB->get_records_sql($sql);
                 $thispageurl = new moodle_url('/local/learningtracks/view.php?id='.$data->id);
        $trackinfo = $DB->get_record('local_learningtracks', array('id' => $data->id));
        $row1=[];
        $row1['RelatedModuleName']=$trackinfo->name;
        $row1['RelatedModulesLink']=$thispageurl;
       $myobject=(new \local_learningtracks\notification);
       $myobject->learningtracks_notification('learningtrack_onchange',$touser, $USER,$row1,$waitinglistid=0);
        return $DB->update_record('local_learningtracks', $row);
    }

    public static function track_organizations($organization = array(),$trackid = 0) {
        global $DB;
         if($organization["0"] == '0') {
            $organizations = [0 => get_string('all', 'local_learningtracks')];
        } elseif(!empty($organization)){
            list($orgsql, $orgparams) = $DB->get_in_or_equal($organization);
            $organizations = $DB->get_records_sql_menu("SELECT id, CONCAT(fullname, ' ', shortname) AS fullname FROM {local_organization} WHERE  id $orgsql",$orgparams);
              
        } elseif($trackid) {
            $org = $DB->get_records_sql_menu("SELECT lo.id, CONCAT(lo.fullname, ' ', lo.shortname) AS fullname FROM {local_organization} lo 
            JOIN {local_learningtracks} lt ON concat(',', lt.organization, ',') LIKE concat('%,',lo.id,',%')
            WHERE lt.id = :trackid",['trackid' => $trackid]);
            /*if(empty($org)) {
                $organizations = ['0' => get_string('all', 'local_learningtracks')];
            } else {
                $organizations =  $org;
            }*/
            $organizations =  $org;
        }
        return $organizations;
    }

    public static function get_learningtrack_entities($trackid) {
        global $DB, $CFG;

        $lowestseats=0;
        
        $programitems = $DB->get_fieldset_sql("SELECT itemid FROM {local_learning_items} WHERE trackid = $trackid AND itemtype = 1 ");
        if($programitems) {
            $programs = array();
           foreach($programitems as $trainingprogram){
                $tpdata = [];
                $programname=$DB->get_field('local_trainingprogram','name', array('id'=>$trainingprogram));
                $getofferings = \local_trainingprogram\local\trainingprogram::get_offerings($trainingprogram, true,true);
                $tpdata['currentofferings'] =$getofferings['tpofferings'];
                $tpdata['title'] = $programname;
                $tpdata['entity'] = 'tp';
                $tpdata['entityid'] = $trainingprogram;
                $programs[] = $tpdata;

                if($lowestseats == 0 || ($lowestseats > $getofferings['tpofferinglowestseats'] && $getofferings['tpofferinglowestseats'] > 0 )){

                    $lowestseats=$getofferings['tpofferinglowestseats'];

                }
           }
        }
          
        $examitems = $DB->get_fieldset_sql("SELECT itemid FROM {local_learning_items} WHERE trackid = $trackid AND itemtype = 2 ");
        if($examitems) {
            $exams = [];
            foreach($examitems as $examid){
                $examdata = [];
                $examtitle=$DB->get_field('local_exams','exam', array('id'=>$examid));

                $getexamreservations=\local_exams\local\exams::get_examreservations($examid,false,true);
                $examdata['examhallreservation'] = $getexamreservations['examhallreservation'];
                $examdata['title'] = $examtitle;
                $examdata['entity'] = 'exam';
                $examdata['entityid'] = $examid;
                $exams[] = $examdata;


                  if($lowestseats == 0 || ($lowestseats > $getexamreservations['reservationlowestseats'] && $getexamreservations['reservationlowestseats'] >0 )){

                    $lowestseats=$getexamreservations['reservationlowestseats'];
                }
            }
        }


        $filterparams['programs'] = $programs;//array_values($tpoffering);
        $filterparams['exams'] = $exams;
        $filterparams['lowestseats'] = $lowestseats;
        return $filterparams;
    }

    public static function track_competency($competency = array(),$trackid = 0) {
        global $DB;
         if(!empty($competency)){
            list($cmpsql, $cmpparams) = $DB->get_in_or_equal($competency);
            $competencylist = $DB->get_records_sql_menu("SELECT lc.id AS id, CONCAT(lc.name, ' ', lc.code) AS fullname FROM {local_competencies} lc WHERE  lc.id $cmpsql",$cmpparams); 
        } elseif($trackid) {
            $competencylist = $DB->get_records_sql_menu("SELECT lo.id AS id, CONCAT(lo.name, ' ', lo.code) AS fullname FROM {local_competencies} lo 
            JOIN {local_learningtracks} lt ON concat(',', lt.competency, ',') LIKE concat('%,',lo.id,',%')
            WHERE lt.id = :trackid",['trackid' => $trackid]);
        }
        return $competencylist;
    }
    
    public function enrol_track($add, $trackid, $roleid, $examlist='', $programlist='') {
        global $OUTPUT, $PAGE, $DB;
        $type = 'learningtrack_enrol';
        $userstoassign = $add;
        $track = $DB->get_record('local_learningtracks', ['id' => $trackid], '*', MUST_EXIST);
        if (!empty($userstoassign)) {
            $progress = 0;
            $progressbar = new \core\progress\display_if_slow(get_string('enrollusers', 'local_learningtracks',$track->name));
            $progressbar->start_html();
            $progressbar->start_progress('',count($userstoassign)-1);
            // foreach($userstoassign as $key=>$adduser){
              // $progressbar->progress($progress);
              // $progress++;
              // $timestart = time();
              // $timeend = 0;
              // if ($timestart==''){
              //     $timestart=0;
              // }
              // $manual = enrol_get_plugin('manual');
              // $roleid = $DB->get_field('role', 'id',array('shortname' => 'trainee'));
              //$instance = $DB->get_record('enrol', array('enrol' => 'manual'), '*', MUST_EXIST);
              //$manual->enrol_user($instance, $adduser,$roleid,$timestart, $timeend);
            try{
                 $transaction = $DB->start_delegated_transaction();
                 foreach($userstoassign as $key=>$adduser){
                  (new \local_learningtracks\learningtracks)->learningtrack_enrollmet($trackid, $adduser, $roleid, $examlist, $programlist);
                }
                  $transaction->allow_commit();
              }catch(moodle_exception $e){
                    $transaction->rollback($e);
                    return false;
                }

            // }
            $progressbar->end_html();
            $result = new stdClass();
            $result->changecount = $progress;
            $result->course = $track->name; 
            echo $OUTPUT->notification(get_string('enrolluserssuccess', 'local_learningtracks',$result),'success');
            $button = new \single_button($PAGE->url, get_string('click_continue','local_learningtracks'), 'get', true);
            $button->class = 'continuebutton';
            echo $OUTPUT->render($button);
            die();
        }
    }

    public function unenrol_track($remove, $trackid, $roleid, $examlist='', $programlist='') {
        global $OUTPUT, $PAGE, $DB;
        $type = 'learningtrack_enrol';
        $userstounassign = $remove;
        $track = $DB->get_record('local_learningtracks', ['id' => $trackid], '*', MUST_EXIST);
        if (!empty($userstounassign)) {
            $progress = 0;
            $progressbar = new \core\progress\display_if_slow(get_string('un_enrollusers', 'local_learningtracks',$track->name));
            $progressbar->start_html();
            $progressbar->start_progress('', count($userstounassign)-1);
            foreach($userstounassign as $key => $removeuser){
                $progressbar->progress($progress);
                $progress++;
                $manual = enrol_get_plugin('manual');
                //$instance = $DB->get_record('enrol', array('courseid' => $exam->courseid, 'enrol' => 'manual'), '*', MUST_EXIST);
                //$manual->unenrol_user($instance, $removeuser);
                $roleid = $DB->get_field('role', 'id',array('shortname' => 'trainee'));
                (new \local_learningtracks\learningtracks)->learningtrack_unenrollmet($trackid, $removeuser, $roleid, $examlist, $programlist);
            }
            $progressbar->end_html();
            $result=new stdClass();
            $result->changecount = $progress;
            $result->course = $track->name; 
            echo $OUTPUT->notification(get_string('unenrolluserssuccess', 'local_learningtracks',$result),'success');
            $button = new \single_button($PAGE->url, get_string('click_continue','local_learningtracks'), 'get', true);
            $button->class = 'continuebutton';
            echo $OUTPUT->render($button);
            die();
        }
    }


    public function is_enrolled($item, $itemtype, $userid) {
        global $DB;
        if($itemtype == product::TRAINING_PROGRAM){
            $programid = $DB->get_field('tp_offerings', 'trainingid', ['id' => $item]);
            if((new \local_trainingprogram\local\trainingprogram)->is_enrolled($progrmid, $userid)){
                return true;
            }
        }else if($itemtype == product::EXAMS){
            $selectsql = " SELECT  le.id
                        FROM mdl_local_exams le
                        JOIN mdl_hall_reservations as hr ON hr.typeid=le.id AND hr.type='exam'
                        WHERE hr.id = ".$item;
            $examid = $DB->get_field_sql($selectsql);
            if((new \local_exams\local\exams)->is_enrolled($examid, $userid)){
                return true;
            }
        }
    }

    public function learningtrackfakeblock() { 
        global $DB, $PAGE, $OUTPUT, $CFG, $USER;
        $systemcontext = context_system::instance();
        $bc = new \block_contents();
        if(!is_siteadmin() && (has_capability('local/organization:manage_trainee', $systemcontext) )) {
            $bc->title = get_string('mylearningtracks','local_learningtracks');
            $bc->attributes['class'] = 'my_training';
            $renderer = $PAGE->get_renderer('local_learningtracks');
            $bc->content =  (new learningtracks)->trainee_learningtrack_data();
            $PAGE->blocks->add_fake_block($bc, 'content');
        }
    }

    public function trainee_learningtrack_data() {
        global $DB,$OUTPUT, $PAGE,$CFG;
        $stable = new \stdClass();
        $stable->thead = false;
        $stable->start = 0;
        $stable->length = 5;
        $data = array();
        $tracks = learningtracks::get_enrolled_learningpath($stable, null); 
        $renderer = $PAGE->get_renderer('local_learningtracks');
        $data['mytracks'] = array_merge($data, $renderer->my_learning_tracks($tracks['tracks']));
        $data['viewmoreurl'] = $CFG->wwwroot."/local/learningtracks/learningpath.php";
        $data['viewmoreurldisplay'] =COUNT($data['mytracks']) > 0 ? true :false;
        return $OUTPUT->render_from_template('local_learningtracks/learningtrack_block', $data);
    }

    public function get_listof_enrolledcourses($trackid, $userid, $status='', $itemid='', $itemtype=''){
        global $DB;
        $usercount = 0;
        $track = $DB->get_record('local_lts_enrolment',['trackid' => $trackid, 'userid' => $userid]);
        if($track) {
            $sql = " SELECT li.* FROM {local_lts_item_enrolment} li WHERE trackid = $track->id AND userid = $track->userid";
            if($status || $status == '0') {
                $sql .= " AND li.status = $status";
            } 
            $order = ' ORDER BY li.id ASC';
            if($itemid) {
                $sql .= " AND li.itemid = $itemid  AND li.itemtype = $itemtype";
                $usercount = $DB->get_record_sql($sql.$order);
            } else {
                $usercount = $DB->get_records_sql($sql.$order);
            }
            
        }
        return $usercount;
    }

    public function completed_items_count($trackid) {
        global $DB;
        $count_sql = " SELECT COUNT(X.itemid) FROM (SELECT ltiten.itemid,COUNT(ltiten.itemid) enroluerscount,(SELECT COUNT(ltiten1.itemid) FROM `mdl_local_lts_item_enrolment` as ltiten1 where ltiten1.itemid=ltiten.itemid and ltiten1.status=1) as compltuerscount  FROM `mdl_local_lts_item_enrolment` as ltiten JOIN `mdl_local_lts_enrolment` AS lten ON lten.id=ltiten.trackid 
        WHERE lten.trackid= $trackid GROUP BY ltiten.itemid HAVING enroluerscount=compltuerscount) AS X";
        $count = $DB->count_records_sql($count_sql);
        return $count;
    }

    public function trackitem_completion_status($trackid, $itemid, $itemtype) {
        global $DB;
        $sql = " SELECT ltiten.itemid,ltiten.itemtype,COUNT(ltiten.itemid) enroluerscount,(SELECT COUNT(ltiten1.itemid) FROM `mdl_local_lts_item_enrolment` as ltiten1 where ltiten1.itemid=ltiten.itemid and ltiten1.status=1) as compltuerscount FROM `mdl_local_lts_item_enrolment` as ltiten JOIN `mdl_local_lts_enrolment` AS lten ON lten.id=ltiten.trackid 
        WHERE lten.trackid=$trackid AND ltiten.itemid = $itemid AND ltiten.itemtype = $itemtype 
        GROUP BY ltiten.itemid, ltiten.itemtype";
        $record = $DB->get_records_sql($sql);
        return $record;
    }

    public function is_current_user_enrolled_to_learningtracks() {
        global $DB,$USER;

        $sql = 'SELECT le.id FROM {local_lts_enrolment} as le 
                JOIN {local_learningtracks} as lt ON lt.id = le.trackid 
                WHERE le.userid =:userid ';
        $enrolled = $DB->record_exists_sql($sql, ['userid' => $USER->id]);
        if($enrolled){
            return true;
        }
        return false;

    }
}
