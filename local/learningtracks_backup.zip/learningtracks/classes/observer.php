<?php
// This file is part of Moodle - htexm://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <htexm://www.gnu.org/licenses/>.
/**
 * Learningtracks Observer Page
 *
 * @package    local_learningtracks
 * @copyright  2022 e abyas  <info@eabyas.com>
 * @license    htexm://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
class local_learningtracks_observer {
    public static function lerningtrack_dependency_deleted(\local_learningtracks\event\learning_track_deleted $track) {
        global $DB;
        $trackitems_exist = $DB->record_exists('local_learning_items', ['trackid' => $track->objectid]);
        if ($trackitems_exist) {
            $DB->delete_records('local_learning_items', ['trackid' => $track->objectid]);
        }
    }

    // Exam completion
    public static function trainingprogram_exam_completion(\local_exams\event\exam_completion_updated $event) {
        global $DB,$CFG,$USER;
        $eventdata = $event->get_record_snapshot('exam_completions', $event->objectid);
        $userid = $event->relateduserid;
        if (($eventdata->completion_status == 0 || $eventdata->completion_status == 1) && $eventdata->userid == $userid) {
            $exams = $DB->get_record('local_exams',array('id'=>$eventdata->examid));
            $getiteme = $DB->get_record('local_lts_item_enrolment',['itemid' => $eventdata->examid, 'userid' => $userid, 'itemtype' => 2]);
            if($getiteme) {
                self::track_completion($getiteme, $userid, $eventdata->completiondate);
                /*$getiteme->status = 1;
                $getiteme->completiondate = $eventdata->completiondate;
                $getiteme->usermodified = $userid;
                $getiteme->timemodified = time();
                $data = $DB->update_record('local_lts_item_enrolment',$getiteme);
                $lts_enrollment =  $DB->get_record('local_lts_item_enrolment',['id' => $getiteme->trackid]);
                if($lts_enrollment) {
                    $DB->update_record('local_lts_enrolment',$getiteme);
                }*/
            }
        }
    }
    // Program completion
    public static function trainingprogram_program_completion(\local_trainingprogram\event\trainingprogram_completion_updated $event) {
        global $DB,$CFG,$USER;
        $eventdata = $event->get_record_snapshot('program_completions', $event->objectid);
        $userid = $event->relateduserid;
        if ((($eventdata->completion_status == 0 || $eventdata->completion_status == 1)) && ($eventdata->userid == $userid)) {
            $getiteme = $DB->get_record('local_lts_item_enrolment',['itemid' => $eventdata->programid, 'userid' => $userid, 'itemtype' => 1]);
            if($getiteme) {
                self::track_completion($getiteme, $userid, $eventdata->completiondate);
            }
        }
    }

    public static function track_completion($getiteme, $userid, $completiondate) {
        global $DB,$CFG,$USER;
        $getiteme->status = 1;
        $getiteme->completiondate = $completiondate;
        $getiteme->usermodified = $userid;
        $getiteme->timemodified = time();
        $data = $DB->update_record('local_lts_item_enrolment',$getiteme);
        $item_sql = " SELECT COUNT(le.trackid) FROM {local_lts_item_enrolment} le WHERE le.userid = $userid AND le.trackid = $getiteme->trackid";
        $items_count = $DB->count_records_sql($item_sql);
        $completed_count = $DB->count_records_sql('SELECT COUNT(le.trackid) FROM {local_lts_item_enrolment} le WHERE le.status = 1 AND userid = '.$userid.'AND le.trackid = '.$getiteme->trackid);
        $lts_enrollment =  $DB->get_record('local_lts_enrolment',['id' => $getiteme->trackid]);
        if($lts_enrollment) {
            if($items_count == $completed_count) {
                $lts_enrollment->status = 1;
                $lts_enrollment->completiondate = $completiondate;
                $lts_enrollment->usermodified = $userid;
                $lts_enrollment->timemodified = time();
                $DB->update_record('local_lts_enrolment',$lts_enrollment);

                // notification learningtrack completion
                $trackinfo = $DB->get_record('local_learningtracks', array('id' => $lts_enrollment->trackid));
                $row=[];
                $row['learningTrackName']=$trackinfo->name;
                $sql="SELECT u.* 
                        FROM {user} u
                        JOIN {local_lts_enrolment} le ON le.userid = u.id
                        WHERE le.trackid = $getiteme->trackid 
                            AND u.confirmed = 1 
                            AND u.suspended = 0 
                            AND u.deleted = 0 
                            AND u.id > 2";
                $touser = $DB->get_records_sql($sql);
                $myobject=(new \local_learningtracks\notification);
                $myobject->learningtracks_notification('learningtrack_completed',$touser, $USER,$row,$waitinglistid=0);
            }
            /*$enrollment_count = $DB->count_records('local_lts_enrolment',['trackid' => $lts_enrollment->trackid]);
            $completed_count = $DB->count_records('local_lts_enrolment',['trackid' => $lts_enrollment->trackid, 'status' => 1]);
            if($enrollment_count == $completed_count) {
                $track_record = $DB->get_record('local_learningtracks',['id' => $lts_enrollment->trackid]);
                $track_item_records = $DB->get_record('local_learning_items', ['trackid'=> $track_record->id]);
                var_dump($track_item_records); exit;
                foreach($track_item_records as $items) {
                    $count_items = $DB->count_records('local_lts_item_enrolment',['itemid' => $items->itemid, 'itemtype' => $items->itemtype, 'status' => 1]);
                    if($count_items > 0) {
                        $track_record->status = 2;
                        $track_record->timemodified = time();
                        $DB->update_record('local_learningtracks', $track_record);
                    }

                }
            }*/
        }
    }
}
