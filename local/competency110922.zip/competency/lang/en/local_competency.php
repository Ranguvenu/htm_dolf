<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Competency language strings
 *
 * @package    local_competency
 * @copyright  2022 e abyas  <info@eabyas.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
$string['pluginname'] = 'Competency'; 
$string['competencymanagement'] = 'Competency Management'; 
$string['createcompetency'] = 'Add Competency';
$string['editcompetency'] = 'Update Competency';
$string['competency_code'] = 'Code'; 
$string['competency_name'] = 'Competency name';
$string['competency_type'] = 'Type';
$string['competency_level'] = 'Level';
$string['competency_description'] = 'Description';
$string['listofcompetencies'] = 'List Of Competencies'; 
$string['competency_sectors'] = 'Sectors';
$string['competency_action'] = 'Action';
$string['addcompetency'] = 'Add New';
$string['competencynofieldsdefined'] = 'Competency No Fields Defined';
$string['corecompetencies'] = 'Core Competencies';
$string['technicalcompetencies'] = 'Technical Competencies';
$string['behavioralcompetencies'] = 'Behavioral Competencies';
$string['competency_levels'] = 'Level {$a}';
$string['toomanylisttoshow'] = 'Too many list ({$a}) to show';
$string['nocompetencys'] = 'Competencies not found';
$string['nocompetencyspermission'] = 'You don\'t have permission to view this page.';
$string['action'] = 'Action';
$string['competency_noperformance'] = 'No# of performance criteria';
$string['codetaken'] = 'Competency is already exists with code "{$a}", please choose other unique code.';
$string['competencypctaken'] = 'Competency Performance Criteria is already exists with this combination, please choose another unique combination.';
$string['errorcompetencynotfound'] = 'Competency not found';
$string['deletecompetency'] = 'Delete Competency';
$string['deletecompetencyconfirmation'] = 'Do you really want delete this <b>{$a}</b> competency?';
$string['competency_criteriano'] = 'Performance criteria {$a}';
$string['competency_kpino'] = 'KPI {$a}';
$string['competency_objectiveno'] = 'Objective {$a}';
$string['competency_criteria'] = 'Performance criteria';
$string['competency_kpi'] = 'KPI';
$string['competency_objective'] = 'Objective';
$string['title'] = 'Title';
$string['valcriterianamerequired'] = 'Please select Performance criteria.';
$string['valkpinamerequired'] = 'Please select KPI.';
$string['valobjectiveidrequired'] = 'Please select Objective.';
$string['valaddcriterianamerequired'] = 'Please enter Performance criteria.';
$string['valaddkpinamerequired'] = 'Please enter KPI.';
$string['valaddobjectiveidrequired'] = 'Please enter Objective.';
$string['valtyperequired'] = 'Please select Type.';
$string['valaddtyperequired'] = 'Please enter Type.';
$string['vallevelrequired'] = 'Please select Level.';
$string['valaddlevelrequired'] = 'Please enter Level.';
$string['assign'] = 'Assign';
$string['nocompetencypcs'] = 'Competency criterias not found';
$string['segment'] = 'Segment';
$string['jobfamily'] = 'Job family';
$string['jobrole'] = 'Job role';
$string['sector'] = 'Sector';
$string['mycompetencies'] = 'My Competencies';
$string['select_sector'] = 'Select sector';
$string['addtypetaken'] = 'Type is already exists , please enter unique type.';
$string['addleveltaken'] = 'Level is already exists , please enter unique level.';
$string['addcriterianametaken'] = 'Performance criteria is already exists , please enter unique performance criteria.';
$string['addkpinametaken'] = 'KPI is already exists , please enter unique KPI.';
$string['addobjectiveidtaken'] = 'Objective is already exists , please enter unique objective.';
$string['competency_jobrole'] = 'Job role';
$string['listofmycompetencies'] = 'List Of My Competencies'; 
$string['mycurrentjobrolecompetencies'] = 'Competencies related to my current job role ({$a->jobrole}) {$a->jobrolelevel}'; 
$string['name'] = 'Name';
$string['enrolledprogramsexams'] = 'Enrolled programs , exams';
$string['exploreallcompetencies'] = 'Explore all competencies';
$string['listofcompetencies'] = 'List Of Competencies'; 
$string['filter_discription'] = 'All the shown filters are here by ...'; 
$string['nextjobjobrolecompetencies'] = 'Recommended Competencies for next level ({$a->jobrole}) {$a->jobrolelevel}'; 
$string['managecompetencies'] = 'Competencies';
$string['other'] = 'Other';
$string['performancecriteria1'] = 'Performance criteria 1';
$string['performancecriteria2'] = 'Performance criteria 2';
$string['performancecriteria3'] = 'Performance criteria 3';
$string['performancecriteria4'] = 'Performance criteria 4';
$string['performancecriteria5'] = 'Performance criteria 5';
$string['kpi1'] = 'KPI 1';
$string['kpi2'] = 'KPI 2';
$string['kpi3'] = 'KPI 3';
$string['kpi4'] = 'KPI 4';
$string['kpi5'] = 'KPI 5';
$string['objective1'] = 'Objective 1';
$string['objective2'] = 'Objective 2';
$string['objective3'] = 'Objective 3';
$string['objective4'] = 'Objective 4';
$string['objective5'] = 'Objective 5';
$string['nocompetencyexams'] = 'Competency assigned exams not found';
$string['nocompetencytrainingprograms'] = 'Competency assigned Training programs not found';
$string['examname'] = 'Exam Name';
$string['examcode'] = 'Exam Code';
$string['objtrainingprograms'] = '<div class="pb-1"><b> Training programs : </b></div>';
$string['objexams'] = '<div class="pb-1 pt-1"><b> Exams : </b></div>';
$string['valobjexamsrequired'] = 'Please select Exams.';
$string['valobjtrainingprogramsrequired'] = 'Please select Training programs.';
$string['assigntrainingprograms'] = 'Assigned Training programs';
$string['assignexams'] = 'Assigned Exams';
$string['linkexamsprogramsquestions'] = 'Link To Exams,Training programs,Questions';
$string['close'] = 'Close';
$string['deletecompetencypc'] = 'Delete Competency Criteria';
$string['deletecompetencypcconfirmation'] = 'Do you really want to delete <b>{$a}</b> ?';
$string['deletecompetencypcobjective'] = 'Delete Competency {$a} ';
$string['deletecompetencypcobjectiveconfirmation'] = 'Do you really want to delete <b>{$a}</b> ?';
$string['programname'] = 'Training program Name';
$string['programcode'] = 'Training program Code';
$string['mysupportedcompetencies'] = 'Supported Competencies'; 
$string['invalidcompetencyid'] = 'Invalid Competency Id';
$string['competencycode'] = 'Competency Code';
$string['competencytitle'] = 'Competency Title';
$string['competencytype'] = 'Competency Type';
$string['competencydescriptor'] = 'Competency Descriptor';
$string['competencylevels'] = 'Levels';
$string['achievementtitle'] = 'Title';
$string['achievementtype'] = 'Learning Item Type';
$string['achievementexam'] = 'Exam';
$string['achievementtrainingprogram'] = 'Training Program';
$string['recommendedcompetencyachievement'] = 'Recommended sources for this level of competency achievement'; 
$string['learningcontent'] = 'View Learning Content';
$string['learningcontenttitle'] = 'Title';
$string['learningcontenttype'] = 'Learning Item Type';
$string['learningcontentexam'] = 'Exams';
$string['learningcontenttrainingprogram'] = 'Training Programs';
$string['viewlearningcontent'] = '<b>{$a}</b> Learning Content';
$string['learningcontent'] = 'Learning Content';
$string['view'] = 'View';
$string['enroll'] = 'Enrol';
$string['eventcompetencycreation'] = 'Competency Created ';
$string['eventcompetencyupdation'] = 'Competency Updated ';
$string['eventcompetencydeletion'] = 'Competency Deleted ';
$string['eventcompetencypccreation'] = 'Competency Performace Criteria Created ';
$string['eventcompetencypcupdation'] = 'Competency Performace Criteria Updated ';
$string['eventcompetencypcdeletion'] = 'Competency Performace Criteria Deleted ';
$string['eventcompetencyobjcreation'] = 'Competency Mapping objective Created ';
$string['eventcompetencyobjupdation'] = 'Competency Mapping objective Updated ';
$string['eventcompetencyobjdeletion'] = 'Competency Mapping objective Deleted ';

$string['objquestions'] = '<div class="pb-1"><b> Questions : </b></div>';
$string['valobjobjquestionsrequired'] = 'Please select Questions.';
$string['learningcontentquestion'] = 'Questions';
$string['nocompetencyquestions'] = 'Competency assigned Questions not found';
$string['questionname'] = 'Question Text';
$string['questiontype'] = 'Question Type';

$string['viewquestioncompetencies'] = '<b>{$a}</b> -- Competencies';
$string['noofquestions'] = 'No of Questions';
$string['showall'] = 'Show all';
$string['nojobroledescription'] = 'Job responsibilities are not added';

$string['nojobrolelevel'] = 'Job levels are not added';
$string['nolearningcontent'] = 'This competency related learning content not added';

$string['question']='Questions';
$string['exam']='Exam';
$string['level']='Level';
$string['trainingprogram']='Training Program';
$string['yes']='Yes';

$string['objjobrolelevels'] = '<div class="pb-1"><b> Levels : </b></div>';
$string['learningcontentlevels'] = 'Levels';
$string['levelname'] = 'Level Name';
$string['nocompetencylevels'] = 'Competency assigned levels not found';
$string['valnamerequired'] ='Name can not be empty.';
$string['valcoderequired'] ='Code can not be empty.';
$string['competency_nameeng'] = 'Competency name (English)';
$string['competency_namearabic'] = 'Competency name (Arabic)';
$string['titleeng'] = 'Title (English)';
$string['titlearabic'] = 'Title (Arabic)';


$string['competencyuploadform'] = 'Upload Competencies';
$string['back_upload'] = 'Back';
$string['help'] = 'Help Manual';
$string['sample'] = 'Download sample excel sheet';
$string['competencyfilerequired'] = 'Competency file required';
$string['competency_upload_help'] = '<table class="generaltable" border="1">
<tr><td style="border-top: 1px solid;
    border-bottom: 1px solid;"><b>Competencies</b></td><td style="text-align:left;border-left: 1px solid rgba(0,0,0,.05);border-top: 1px solid;border-bottom: 1px solid;padding-left:45px;"><b>Mandatory Fields</b></td><tr>
<th>Field</th><th>Restriction</th>
<tr><td>OLD_ID</td><td>Old Id</td></tr>
<tr><td>EN_Name</td><td>English Name</td></tr>
<tr><td>AR_Name</td><td>Arabic Name</td></tr>
<tr><td>TYPE</td><td>Type</td></tr>
<tr><td>Code</td><td>Code</td></tr>
<tr><td>EXAM_CODE</td><td>Exam Code</td></tr>
<tr><td>PROGRAM_CODE</td><td>Training Program Code</td></tr>
<tr><td>QUESTION_CODE</td><td>Question Code</td></tr>
<tr><td>LEVEL</td><td>Level</td></tr>
</table>';
$string['uploadcompetency'] = 'Upload Competencies';
$string['competencyupload'] = 'Competency Upload';

$string['oldidmissing'] = '<div class="alert alert-danger">OLD_ID is missing from headers.</div>';
$string['oldidempty'] = '<div class="alert alert-danger">Please enter OLD_ID in uploaded sheet at line {$a->excel_line_number}.</div>';

$string['parentcodemissing'] = '<div class="alert alert-danger">PARENT_CODE is missing from headers.</div>';
$string['parentcodeempty'] = '<div class="alert alert-danger">Please enter PARENT_CODE in uploaded sheet at line {$a->excel_line_number}.</div>';

$string['codemissing'] = '<div class="alert alert-danger">CODE is missing from headers.</div>';
$string['nameenglishmissing'] = '<div class="alert alert-danger">EN_Name is missing from headers.</div>';
$string['namearabicmissing'] = '<div class="alert alert-danger">AR_Name is missing from headers.</div>';
$string['descriptionmissing'] = '<div class="alert alert-danger">Description is missing from headers.</div>';
$string['typemissing'] = '<div class="alert alert-danger">TYPE is missing from headers.</div>';
$string['sectormemissing'] = '<div class="alert alert-danger">CompetencySector is missing from headers.</div>';
$string['segmentmissing'] = '<div class="alert alert-danger">CompetencySegment is missing from headers.</div>';
$string['jobfamilymissing'] = '<div class="alert alert-danger">CompetencyJobfamily is missing from headers.</div>';
$string['jobrolemissing'] = '<div class="alert alert-danger">CompetencyJobrole is missing from headers.</div>';
$string['performancecompetencycodemissing'] = '<div class="alert alert-danger">PerformanceCompetencyCode is missing from headers.</div>';
$string['performancecriterianamemissing'] = '<div class="alert alert-danger">PerformanceCriteriaName is missing from headers.</div>';
$string['performancekpinamemissing'] = '<div class="alert alert-danger">PerformanceKPIName is missing from headers.</div>';
$string['performanceobjectiveidmissing'] = '<div class="alert alert-danger">PerformanceObjectiveID is missing from headers.</div>';
$string['learningcontentcompetencycodemissing'] = '<div class="alert alert-danger">LearningcontentCompetencyCode is missing from headers.</div>';
$string['learningcontentcriterianamemissing'] = '<div class="alert alert-danger">LearningcontentCriteriaName is missing from headers.</div>';
$string['learningcontentkpinamemissing'] = '<div class="alert alert-danger">LearningcontentKPIName is missing from headers.</div>';
$string['learningcontentobjectiveidmissing'] = '<div class="alert alert-danger">LearningcontentObjectiveID is missing from headers.</div>';
$string['examcodemissing'] = '<div class="alert alert-danger">EXAM_CODE is missing from headers.</div>';
$string['programcodemissing'] = '<div class="alert alert-danger">PROGRAM_CODE is missing from headers.</div>';
$string['questioncodemissing'] = '<div class="alert alert-danger">QUESTION_CODE is missing from headers.</div>';

$string['codeempty'] = '<div class="alert alert-danger">Please enter CODE in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['nameenglishempty'] = '<div class="alert alert-danger">Please enter EN_Name in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['namearabicempty'] = '<div class="alert alert-danger">Please enter AR_Name in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['descriptionempty'] = '<div class="alert alert-warning">Please enter Description in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['typeempty'] = '<div class="alert alert-danger">Please enter TYPE in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['sectorempty'] = '<div class="alert alert-danger">Please enter CompetencySector in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['sectornotmatchedwithrecords'] ='<div class="alert alert-danger">Given <b>{$a->competencysector}</b> CompetencySector is not matched with records at line {$a->excel_line_number}.</div>';
$string['segmentempty'] ='<div class="alert alert-danger">Please enter CompetencySegment in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['segmentnotmatchedwithrecords'] ='<div class="alert alert-danger">Given <b>{$a->competencysegment}</b> CompetencySegment is not matched with records at line {$a->excel_line_number}.</div>';
$string['jobfamilyempty'] ='<div class="alert alert-danger">Please enter CompetencyJobfamily in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['jobfamilynotmatchedwithrecords'] ='<div class="alert alert-danger">Given <b>{$a->competencyjobfamily}</b> CompetencyJobfamily is not matched with records at line {$a->excel_line_number}.</div>';
$string['jobroleempty'] ='<div class="alert alert-danger">Please enter CompetencyJobrole in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['jobrolenotmatchedwithrecords'] ='<div class="alert alert-danger">Given <b>{$a->competencyjobrole}</b> CompetencyJobrole are not matched with records at line {$a->excel_line_number}.</div>';
$string['performancecriterianameempty'] ='<div class="alert alert-danger">Please enter PerformanceCriteriaName in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['performancekpinameempty'] ='<div class="alert alert-danger">Please enter PerformanceKPIName in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['performanceobjectiveidempty'] ='<div class="alert alert-danger">Please enter PerformanceObjectiveID in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['examcodeempty'] ='<div class="alert alert-danger">Please enter EXAM_CODE in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['examcodenotmatchedwithrecords'] ='<div class="alert alert-danger">Given <b>{$a->EXAM_CODE}</b> EXAM_CODE is not mapped with given CODE records at line {$a->excel_line_number}.Please enter mapped CODE new EXAM_CODE in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['programcodeempty'] ='<div class="alert alert-danger">Please enter PROGRAM_CODE in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['programcodenotmatchedwithrecords'] ='<div class="alert alert-danger">Given <b>{$a->PROGRAM_CODE}</b> PROGRAM_CODE is not mapped with given CODE records at line {$a->excel_line_number}.Please enter mapped CODE new PROGRAM_CODE in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['questioncodeempty'] ='<div class="alert alert-danger">Please enter QUESTION_CODE in uploaded sheet at line {$a->excel_line_number}.</div>';
$string['questioncodenotmatchedwithrecords'] ='<div class="alert alert-danger">Given <b>{$a->QUESTION_CODE}</b> QUESTION_CODE is not mapped with given CODE records at line {$a->excel_line_number}.Please enter mapped CODE new QUESTION_CODE in uploaded sheet at line {$a->excel_line_number}.</div>';

$string['validsheet'] = 'Please upload valid file. {$a} in uploaded sheet';

$string['successcompetencyupdated'] = '<div class="alert alert-success">Successfully updated <b>{$a->CODE}</b> CODE in uploaded sheet at line {$a->excel_line_number}.</div>';

$string['sucesscompetencycreated'] = '<div class="alert alert-success">Successfully created <b>{$a->CODE}</b> CODE in uploaded sheet at line {$a->excel_line_number}.</div>';

$string['sucesscompetencypccreated'] = '<div class="alert alert-success">Successfully competency criteria created with this <b>{$a->CODE}</b> CODE,<b>{$a->performancecriterianame}</b> PerformanceCriteriaName,<b>{$a->performancekpiname}</b> PerformanceKPIName,<b>{$a->performanceobjectiveid}</b> PerformanceObjectiveID data in uploaded sheet at line {$a->excel_line_number}.</div>';


$string['sucesscompetencypcupdated'] = '<div class="alert alert-success">Successfully competency criteria updated with this <b>{$a->CODE}</b> CODE,<b>{$a->performancecriterianame}</b> PerformanceCriteriaName,<b>{$a->performancekpiname}</b> PerformanceKPIName,<b>{$a->performanceobjectiveid}</b> PerformanceObjectiveID data in uploaded sheet at line {$a->excel_line_number}.</div>';


$string['sucesscompetencypccontentexamscreated'] = '<div class="alert alert-success">Successfully competency criteria learning content exams mapped with this <b>{$a->CODE}</b> CODE,<b>{$a->performancecriterianame}</b> PerformanceCriteriaName,<b>{$a->performancekpiname}</b> PerformanceKPIName,<b>{$a->performanceobjectiveid}</b> PerformanceObjectiveID,,<b>{$a->EXAM_CODE}</b> EXAM_CODE data in uploaded sheet at line {$a->excel_line_number}.</div>';

$string['sucesscompetencypccontentprogramscreated'] = '<div class="alert alert-success">Successfully competency criteria learning content training programs mapped with this <b>{$a->CODE}</b> CODE,<b>{$a->performancecriterianame}</b> PerformanceCriteriaName,<b>{$a->performancekpiname}</b> PerformanceKPIName,<b>{$a->performanceobjectiveid}</b> PerformanceObjectiveID,,<b>{$a->PROGRAM_CODE}</b> PROGRAM_CODE data in uploaded sheet at line {$a->excel_line_number}.</div>';

$string['sucesscompetencypccontentquestionscreated'] = '<div class="alert alert-success">Successfully competency criteria learning content questions mapped with this <b>{$a->CODE}</b> CODE,<b>{$a->performancecriterianame}</b> PerformanceCriteriaName,<b>{$a->performancekpiname}</b> PerformanceKPIName,<b>{$a->performanceobjectiveid}</b> PerformanceObjectiveID,,<b>{$a->QUESTION_CODE}</b> QUESTION_CODE data in uploaded sheet at line {$a->excel_line_number}.</div>';

$string['uploadafile']= 'Upload Competencies';
$string['uploadcompetencysheet'] = 'File uploaded successfully.';

$string['messageprovider:competency_completions']='Competency Completions';
$string['messageprovider:competency_adding_learning_item']="Competency Adding Learning Item";
$string['messageprovider:competency_removing_learning_item']="Competency Removing Learning Item";
$string['details']="Details";
$string['filter']="Filter";
$string['edit']='Edit';
$string['delete']='Delete';
$string['assignperformance']='Assign Performance';
$string['assignobjective']='Assign Objective';
$string['search_competency']='Search Competencies..';
$string['remove_dependency'] = 'You cannot delete this as it is mapped somewhere';
$string['upload_competency'] = 'Upload Competency';

$string['competency:managecompetencies'] = 'Manage Competencies';
$string['competency:canbulkuploadcompetency'] = 'Competency bulk upload';
$string['competency:viewtraineecompetencies'] = 'View trainee competencies';
$string['close_filter'] ='Close';

$string['level1'] = 'Level 1';
$string['level2'] = 'Level 2';
$string['level3'] = 'Level 3';
$string['level4'] = 'Level 4';
$string['level5'] = 'Level 5';

$string['oldid'] = 'OLD_ID';
$string['levelmissing'] = '<div class="alert alert-danger">LEVEL is missing from headers.</div>';
$string['levelempty'] = '<div class="alert alert-danger">Please enter LEVEL in uploaded sheet at line {$a->excel_line_number}.</div>';