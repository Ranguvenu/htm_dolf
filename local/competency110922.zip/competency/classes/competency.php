<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Class containing helper methods for processing data requests.
 *
 * @package    local_competency
 * @copyright  2022 e abyas  <info@eabyas.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_competency;

use coding_exception;
use context_helper;
use context_system;
use core\invalid_persistent_exception;
use core\message\message;
use core_user;
use dml_exception;
use moodle_exception;
use moodle_url;
use required_capability_exception;
use stdClass;

defined('MOODLE_INTERNAL') || die();

/**
 * Class containing helper methods for processing data requests.
 *
 * @copyright  2018 Jun Pataleta
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class competency {

    const CORECOMPETENCIES = 'corecompetencies';
    const TECHNICALCOMPETENCIES = 'technicalcompetencies';
    const BEHAVIORALCOMPETENCIES = 'behavioralcompetencies';

    const PERFORMANCECRITERIA1= 'performancecriteria1';
    const PERFORMANCECRITERIA2 = 'performancecriteria2';
    const PERFORMANCECRITERIA3 = 'performancecriteria3';
    const PERFORMANCECRITERIA4 = 'performancecriteria4';
    const PERFORMANCECRITERIA5 = 'performancecriteria5';

    const KPI1= 'kpi1';
    const KPI2 = 'kpi2';
    const KPI3 = 'kpi3';
    const KPI4 = 'kpi4';
    const KPI5 = 'kpi5';

    const OBJECTIVE1= 'objective1';
    const OBJECTIVE2 = 'objective2';
    const OBJECTIVE3 = 'objective3';
    const OBJECTIVE4 = 'objective4';
    const OBJECTIVE5 = 'objective5';

    const OTHER = 'other';

    const LEVEL1= 'level1';
    const LEVEL2 = 'level2';
    const LEVEL3 = 'level3';
    const LEVEL4 = 'level4';
    const LEVEL5 = 'level5';

 

    public static function constcompetencytypes() {

        $competencytypes = array(
            self::CORECOMPETENCIES => get_string('corecompetencies','local_competency'),
            self::TECHNICALCOMPETENCIES => get_string('technicalcompetencies','local_competency'),
            self::BEHAVIORALCOMPETENCIES => get_string('behavioralcompetencies','local_competency')
            );


        return $competencytypes;
    }

    public static function constperformancecriterias() {

        $performancecriterias = array(
                    self::PERFORMANCECRITERIA1 => get_string('performancecriteria1','local_competency'),
                    self::PERFORMANCECRITERIA2 => get_string('performancecriteria2','local_competency'),
                    self::PERFORMANCECRITERIA3 => get_string('performancecriteria3','local_competency'),
                    self::PERFORMANCECRITERIA4 => get_string('performancecriteria4','local_competency'),
                    self::PERFORMANCECRITERIA5 => get_string('performancecriteria5','local_competency')
                    );


        return $performancecriterias;
    }

    public static function constkpis() {

        $kpis = array(
            self::KPI1 => get_string('kpi1','local_competency'),
            self::KPI2 => get_string('kpi2','local_competency'),
            self::KPI3 => get_string('kpi3','local_competency'),
            self::KPI4 => get_string('kpi4','local_competency'),
            self::KPI5 => get_string('kpi5','local_competency')
            );


        return $kpis;
    }

    public static function constobjectives() {

        $objectives = array(
                    self::OBJECTIVE1 => get_string('objective1','local_competency'),
                    self::OBJECTIVE2 => get_string('objective2','local_competency'),
                    self::OBJECTIVE3 => get_string('objective3','local_competency'),
                    self::OBJECTIVE4 => get_string('objective4','local_competency'),
                    self::OBJECTIVE5 => get_string('objective5','local_competency')
                    );


        return $objectives;
    }
    public static function constcompetencylevels() {

        $kpis = array(
            self::LEVEL1 => get_string('level1','local_competency'),
            self::LEVEL2 => get_string('level2','local_competency'),
            self::LEVEL3 => get_string('level3','local_competency'),
            self::LEVEL4 => get_string('level4','local_competency'),
            self::LEVEL5 => get_string('level5','local_competency')
            );


        return $kpis;
    }

    public static function userjobrolelevelinfo() {

        global $DB, $USER;

        $currentlang= current_language();

        if( $currentlang == 'ar'){

            $titlefield='jbrl.titlearabic';

        }else{

            $titlefield='jbrl.title';
        }

        $levels = array(1=>'Level 1',2=>'Level 2',3=>'Level 3',4=>'Level 4',5=>'Level 5');

        $userinfo=$DB->get_record_sql("SELECT jbrl.id as currentjobroleid,$titlefield as currentjobrole,jbrl.level as currentjobrolelevel,jbrl.jobfamily 
                                       FROM {local_users} as ud
                                       JOIN {local_jobrole_level} as jbrl ON jbrl.id=ud.jobrole
                                       WHERE ud.userid=:userid",array('userid'=>$USER->id));

        $fliplevels=array_flip($levels);

        $nextleveluserinfo=$DB->get_record_sql("SELECT jbrl.id as nextjobroleid,$titlefield as nextjobrole,jbrl.level as nextjobrolelevel  
                                                FROM {local_jobrole_level} as jbrl
                                                WHERE jbrl.jobfamily =:jobfamily AND jbrl.level=:level",array('jobfamily'=>$userinfo->jobfamily,'level'=> $levels[$fliplevels[$userinfo->currentjobrolelevel]+1] ));

        if($nextleveluserinfo){

            $userinfo=(object)array_merge((array)$userinfo,(array)$nextleveluserinfo);

        }

        return $userinfo;
    }

    public static function can_competency_datasubmit() {

        $context = \context_system::instance();

        if((has_capability('local/competency:managecompetencies', $context)) || (has_capability('local/competency:canaddcompetency', $context))){

            return true;
        }

        return false;
    }
    public static function can_competencyperformance_datasubmit() {

        $context = \context_system::instance();

        if((has_capability('local/competency:managecompetencies', $context)) || (has_capability('local/competency:canaddcompetencyperformance', $context))){

            return true;
        }

        return false;
    }
    public static function can_competencyobjective_datasubmit() {

        $context = \context_system::instance();

        if((has_capability('local/competency:managecompetencies', $context)) || (has_capability('local/competency:canaddcompetencyobjectives', $context))){

            return true;
        }

        return false;
    }
    public static function competency_datasubmit($formdata) {
        global $DB, $USER;
        
        try {

            $formdata->description=$formdata->description['text'];

            if(isset($formdata->type) && $formdata->type == self::OTHER){

                $formdata->type = $formdata->add_type;
            }

            $formdata->jobroleid =0;

            if(isset($formdata->level) && $formdata->level == self::OTHER){

                $formdata->level = $formdata->add_level;
            }


            if(isset($formdata->level) && !empty($formdata->level)){

                $formdata->level=implode(',',array_filter($formdata->level));

            }else{
                $formdata->level=NULL;
            }
            

            if($formdata->id > 0){

                $formdata->timemodified=time();
                $formdata->usermodified=$USER->id;

                $id=$DB->update_record('local_competencies', $formdata);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $formdata->id                         
                    );
                $event = \local_competency\event\competency_updated::create($params)->trigger();

                return  $formdata->id;

            }else{

                $formdata->timecreated=time();
                $formdata->usercreated=$USER->id;

                $id=$DB->insert_record('local_competencies', $formdata);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $id                         
                    );
                $event = \local_competency\event\competency_created::create($params)->trigger();

                return  $id;
            }

        } catch (dml_exception $e) {
            print_error($e);

        }
        return true;
    }
    public static function competencyobjective_datasubmit($formdata) {
        global $DB, $USER,$CFG;

        try {


            if(isset($formdata->objjobrolelevels) && !empty($formdata->objjobrolelevels)){

                $learningitemtype='jobrolelevel';

                $formdata->jobrolelevelids=implode(',',array_filter($formdata->objjobrolelevels));

            }else{
                $formdata->jobrolelevelids=NULL;
            }

            if(isset($formdata->objexams) && !empty($formdata->objexams)){

                $learningitemtype='exam';

                $learningitemid=array_filter($formdata->objexams);

                $formdata->examids=implode(',',array_filter($formdata->objexams));

            }else{
                $formdata->examids=NULL;
            }

            if(isset($formdata->objtrainingprograms) && !empty($formdata->objtrainingprograms)){

                $learningitemtype='trainingprogram';

                $learningitemid=array_filter($formdata->objtrainingprograms);

                $formdata->trainingprogramids=implode(',',array_filter($formdata->objtrainingprograms));

            }else{
                $formdata->trainingprogramids=NULL;
            }

            if(isset($formdata->objquestions) && !empty($formdata->objquestions)){

                $learningitemtype='question';

                $learningitemid=array_filter($formdata->objquestions);

                $formdata->questionids=implode(',',array_filter($formdata->objquestions));

            }else{
                $formdata->questionids=NULL;
            }

            $sql ="SELECT cpcbj.id,cpcbj.examids,cpcbj.trainingprogramids,cpcbj.questionids,cpcbj.jobrolelevelids FROM {local_competencypc_obj} AS cpcbj 
                WHERE cpcbj.competencypc=:competencypc AND cpcbj.competency=:competency"; 

            $competencypcobj=$DB->get_record_sql($sql, ['competencypc' => $formdata->competencypc,'competency' => $formdata->competency]);


            if($competencypcobj){

                $formdata->id=$competencypcobj->id;

                if(isset($formdata->objtrainingprograms) && !empty($formdata->objtrainingprograms)){

                    $formdata->trainingprogramids=implode(',',array_filter(array_merge(explode(',',$competencypcobj->trainingprogramids),$formdata->objtrainingprograms)));

                }else{
                    $formdata->trainingprogramids=$competencypcobj->trainingprogramids;
                }

                if(isset($formdata->objexams) && !empty($formdata->objexams)){
                    
                    $formdata->examids=implode(',',array_filter(array_merge(explode(',',$competencypcobj->examids),$formdata->objexams)));

                }else{
                    $formdata->examids=$competencypcobj->examids;
                }

                if(isset($formdata->objquestions) && !empty($formdata->objquestions)){

                    $formdata->questionids=implode(',',array_filter(array_merge(explode(',',$competencypcobj->questionids),$formdata->objquestions)));

                }else{
                    $formdata->questionids=$competencypcobj->questionids;
                }

                if(isset($formdata->objjobrolelevels) && !empty($formdata->objjobrolelevels)){


                    $formdata->jobrolelevelids=implode(',',array_filter(array_merge(explode(',',$competencypcobj->jobrolelevelids),$formdata->objjobrolelevels)));

                }else{
                    $formdata->jobrolelevelids=$competencypcobj->jobrolelevelids;
                }

                $formdata->timemodified=time();
                $formdata->usermodified=$USER->id;

                $id=$DB->update_record('local_competencypc_obj', $formdata);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $formdata->id                         
                    );
                $event = \local_competency\event\competency_obj_updated::create($params)->trigger();
                $formdata->competency_link=$CFG->wwwroot.'local/competency/index.php?id='.$formdata->competency;

                if($learningitemtype !='jobrolelevel'){

                    $formdata->learningitemtype=$learningitemtype;

                    $formdata->learningitemid=$learningitemid;

                   $formdata->competency_name=$DB->get_field('local_competencies','name',array('id'=>$formdata->competency));

                   (new \local_competency\notification())->competency_notification('competency_adding_learning_item', $touser=get_admin(),$fromuser=get_admin(),$formdata,$waitinglistid=0);
                }


            }else{

                $formdata->timecreated=time();
                $formdata->usercreated=$USER->id;

                $id=$DB->insert_record('local_competencypc_obj', $formdata);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $id                         
                    );
                $event = \local_competency\event\competency_obj_created::create($params)->trigger();


                if($learningitemtype !='jobrolelevel'){


                    $formdata->learningitemtype=$learningitemtype;

                    $formdata->learningitemid=$learningitemid;

                    $formdata->competency_name=$DB->get_field('local_competencies','name',array('id'=>$formdata->competency));

                    (new \local_competency\notification())->competency_notification('competency_adding_learning_item', $touser=get_admin(),$fromuser=get_admin(),$formdata,$waitinglistid=0);
                }



            }

        } catch (dml_exception $e) {
            print_error($e);

        }
        return true;
    }
    public static function competencypc_datasubmit($formdata) {
        global $DB, $USER;

        try {

            if(isset($formdata->criterianame) && $formdata->criterianame == self::OTHER){

                $formdata->criterianame = $formdata->add_criterianame;
            }

            if(isset($formdata->kpiname) && $formdata->kpiname == self::OTHER){

                $formdata->kpiname = $formdata->add_kpiname;
            }

            if(isset($formdata->objectiveid) && $formdata->objectiveid == self::OTHER){

                $formdata->objectiveid = $formdata->add_objectiveid;
            }

            if($formdata->id > 0){

                $formdata->timemodified=time();
                $formdata->usermodified=$USER->id;

                $id=$DB->update_record('local_competency_pc', $formdata);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $formdata->id                        
                    );
                $event = \local_competency\event\competencypc_updated::create($params)->trigger();

                return  $formdata->id;

            }else{

                $formdata->timecreated=time();
                $formdata->usercreated=$USER->id;

                $id=$DB->insert_record('local_competency_pc', $formdata);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $id                         
                    );
                $event = \local_competency\event\competencypc_created::create($params)->trigger();

                return  $id;
            }

        } catch (dml_exception $e) {
            print_error($e);

        }
        return true;
    }
    public static function get_competencies($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $competencies      = array();
        $competenciescount = 0;
        $concatsql       = '';

         $currentlang= current_language();

        if($currentlang == 'ar'){

          $titlefield='cmt.arabicname';

        }else{

            $titlefield='cmt.name';
        }

        if (!empty($filterdata->search_query)) {

       
            $fields = array(
                $titlefield,"cmt.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            $concatsql .= " AND cmt.id = :competencyid";
            $params['competencyid'] = $stable->competencyid;
        }

        $countsql = "SELECT COUNT(cmt.id) ";
        


        if (isset($stable->questionid) && $stable->questionid > 0) {

            $params['questionid'] = $stable->questionid;

            $fromsql = "SELECT cmt.*,$titlefield as name ,q.questiontext,qbcmt.questionbankid";

            $sql = " FROM {local_competencies} AS cmt
                     JOIN {local_questioncompetencies} AS qbcmt ON FIND_IN_SET(cmt.id,qbcmt.competency) > 0
                     JOIN {question} q ON q.id=qbcmt.questionid
                     WHERE q.id=:questionid ";

        }else{

            $fromsql = "SELECT cmt.*,$titlefield as name ";

            $sql = " FROM {local_competencies} AS cmt
                    WHERE cmt.id > 0 ";

        }

        $sql .= $concatsql;

        if(!empty($filterdata->type)){

            if(!empty($filterdata->type)){
                $typelist = explode(',',$filterdata->type);
            }
    
            list($relatedtypelistsql, $relatedtypelistparams) = $DB->get_in_or_equal($typelist, SQL_PARAMS_NAMED, 'typelist');
            $params = array_merge($params,$relatedtypelistparams);
            $sql .= " AND cmt.type $relatedtypelistsql";

        }

        if(!empty($filterdata->level)){

            if(!empty($filterdata->level)){
                $levellist = explode(',',$filterdata->level);
            }
    
            list($relatedlevellistsql, $relatedlevellistparams) = $DB->get_in_or_equal($levellist, SQL_PARAMS_NAMED, 'levellist');
            $params = array_merge($params,$relatedlevellistparams);
            $sql .= " AND cmt.level $relatedlevellistsql";

        }

        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            $competencies = $DB->get_record_sql($fromsql . $sql, $params);
        } else {
            try {
                
                $competenciescount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY cmt.id DESC";

                    $competencies = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $competenciescount = 0;
            }
        }
        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            return $competencies;
        } else {
            return compact('competencies', 'competenciescount');
        }
    }
    public static function get_competency_performances($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $competencies      = array();
        $competenciescount = 0;
        $concatsql       = '';

        $currentlang= current_language();

        if($currentlang == 'ar'){

            $cmtitlefield='cmt.arabicname';

            $crtitlefield='cmpc.criterianamearabic';

            $kptitlefield='cmpc.kpinamearabic';

            $objtitlefield='cmpc.objectiveidarabic';

        }else{

            $cmtitlefield='cmt.name';

            $crtitlefield='cmpc.criterianame';

            $kptitlefield='cmpc.kpiname';

            $objtitlefield='cmpc.objectiveid';
        }

        if (!empty($stable->search)) {



            $fields = array(
                $titlefield,$kptitlefield,$objtitlefield
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $fields .= " LIKE :search3 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $params['search3'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            $concatsql .= " AND cmpc.competency = :competencyid";
            $params['competencyid'] = $stable->competencyid;
        }

        if (isset($stable->id) && $stable->id > 0) {
            $concatsql .= " AND cmpc.id = :id";
            $params['id'] = $stable->id;
        }


        $countsql = "SELECT COUNT(cmpc.id) ";


        if (isset($stable->questionid) && $stable->questionid > 0) {

            $params['questionid'] = $stable->questionid;

            $fromsql = "SELECT cmpc.*,$cmtitlefield as competencyname,$crtitlefield,$kptitlefield,$objtitlefield ,q.questiontext";

            $sql = " FROM {local_competencypc_obj} AS cmpobj
                     JOIN {local_competency_pc} AS cmpc ON cmpc.id=cmpobj.competencypc 
                     JOIN {local_competencies} AS cmt ON cmt.id=cmpc.competency
                     JOIN {local_qb_competencies} AS qbcmt ON FIND_IN_SET(cmt.id,qbcmt.competency) > 0
                     JOIN {question} q ON q.id=qbcmt.questionid
                     WHERE q.id=:questionid AND FIND_IN_SET(q.id,cmpobj.questionids) > 0";

        }else{

            $fromsql = "SELECT cmpc.*,$cmtitlefield as competencyname,$crtitlefield,$kptitlefield,$objtitlefield ";
            $sql = " FROM {local_competency_pc} AS cmpc
                     JOIN {local_competencies} AS cmt ON cmt.id=cmpc.competency
                    WHERE cmpc.id > 0 "; 
        }

        $sql .= $concatsql;

        if (isset($stable->id) && $stable->id > 0) {
            $competencypc = $DB->get_record_sql($fromsql . $sql, $params);
        } else {
            try {

                $competencypccount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY cmpc.id DESC";

                    $competencypc = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $competencypccount = 0;
            }
        }
        if (isset($stable->id) && $stable->id > 0) {
            return $competencypc;
        } else {
            return compact('competencypc', 'competencypccount');
        }
    }
    public static function get_competency_objective($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $competencies      = array();
        $competenciescount = 0;
        $concatsql       = '';

        $currentlang= current_language();

         if($currentlang == 'ar'){

            $crtitlefield='cmpc.criterianamearabic';

            $kptitlefield='cmpc.kpinamearabic';

            $objtitlefield='cmpc.objectiveidarabic';

        }else{

           $crtitlefield='cmpc.criterianame';

           $kptitlefield='cmpc.kpiname';

           $objtitlefield='cmpc.objectiveid';
        }

        if (!empty($stable->search)) {

            $fields = array(
                $titlefield,$kptitlefield,$objtitlefield
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $fields .= " LIKE :search3 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $params['search3'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }


        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            $concatsql .= " AND cmpc.competency = :competencyid";
            $params['competencyid'] = $stable->competencyid;
        }


        if (isset($stable->id) && $stable->id > 0) {
            $concatsql .= " AND cmobj.id = :id";
            $params['id'] = $stable->id;
        }


        $countsql = "SELECT COUNT(cmobj.id) ";
        $fromsql = "SELECT cmobj.* ,$crtitlefield as criterianame,$kptitlefield as kpiname,$objtitlefield as objectiveid ";
        $sql = " FROM {local_competency_pc} AS cmpc
                 JOIN {local_competency_obj} AS cmobj ON cmpc.objectiveid=cmobj.objective
                WHERE cmobj.id > 0 "; 

        $sql .= $concatsql;

        if (isset($stable->id) && $stable->id > 0) {
            $competencyobj = $DB->get_record_sql($fromsql . $sql, $params);
        } else {
            try {

                $competencyobjcount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY cmobj.id DESC";

                    $competencyobj = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $competencyobjcount = 0;
            }
        }
        if (isset($stable->id) && $stable->id > 0) {
            return $competencyobj;
        } else {
            return compact('competencyobj', 'competencyobjcount');
        }
    }
    public static function competency_types($searchparams='',$limitfrom=0, $limitnum=0) {

        global $DB, $USER;

        $competencytypes = self::constcompetencytypes();


        list($relatedcompetencytypessql, $relatedcompetencytypesparams) = $DB->get_in_or_equal(array_flip($competencytypes), SQL_PARAMS_NAMED, 'competencytypes',false);
        $params = $relatedcompetencytypesparams;

        $sql = "SELECT cmt.type,cmt.type as fullname FROM {local_competencies} AS cmt
                WHERE cmt.type $relatedcompetencytypessql ";

        if (!empty($searchparams)) {

            $sql .= " AND (cmt.type LIKE :search )";
            $params['search'] = '%' . $searchparams . '%';

        }

        $competencietypes=$DB->get_records_sql_menu($sql,$params,$limitfrom,$limitnum);

        if (!empty($searchparams)) {

            return $competencietypes;
        }

        $competencietypes[self::OTHER] = get_string('other','local_competency');
            
        return array_merge($competencytypes,$competencietypes);
    }
    public static function competency_levels($searchparams,$limitfrom=0, $limitnum=0) {

        global $DB, $USER;

        $competencylevels = self::constcompetencylevels();

        return $competencylevels;


        // list($relatedcompetencylevelssql, $relatedcompetencylevelsparams) = $DB->get_in_or_equal(array_flip($competencylevels), SQL_PARAMS_NAMED, 'competencylevels',false);
        // $params = $relatedcompetencylevelsparams;


        // $sql = "SELECT cmt.level,cmt.level as fullname FROM {local_competencies} AS cmt
        //         WHERE cmt.level $relatedcompetencytypessql ";

        // if (!empty($searchparams)) {

        //     $sql .= " AND (cmt.level LIKE :search )";
        //     $params['search'] = '%' . $searchparams . '%';

        // }

        // $competencielevels=$DB->get_records_sql_menu($sql,$params,$limitfrom,$limitnum);

        // if (!empty($searchparams)) {

        //     return $competencielevels;
        // }

        // $competencielevels[self::OTHER] = get_string('other','local_competency');
            
        // return array_merge($competencylevels,$competencielevels);
            
    }
    public function delete_competency($competencyid) {

        global $DB;

        if ($competencyid > 0) {

            $id =$DB->delete_records('local_competencies', ['id' => $competencyid]);
            $params = array(
                'context' => context_system::instance(),        
                'objectid' => $id                         
                );
            $event = \local_competency\event\competency_deleted::create($params)->trigger();
            $competencypc=$DB->record_exists('local_competency_pc', ['competency' => $competencyid]);

            if($competencypc){

                $pcid = $DB->delete_records('local_competency_pc', ['competency' => $competencyid]);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $pcid                         
                    );
                $event = \local_competency\event\competencypc_deleted::create($params)->trigger();
            }

            $competencypcobj=$DB->record_exists('local_competencypc_obj', ['competency' => $competencyid]);

            if($competencypcobj){

                $objid = $DB->delete_records('local_competencypc_obj', ['competency' => $competencyid]);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $objid                         
                    );
                $event = \local_competency\event\competency_obj_deleted::create($params)->trigger();
            }

            return true;
        } 

        return false;
    }
    public static function competency_criteria($searchparams,$limitfrom=0, $limitnum=0) {

        global $DB, $USER;

        $currentlang= current_language();

         if($currentlang == 'ar'){

          $crtitlefield='cmt.criterianamearabic';

        }else{

           $crtitlefield='cmt.criterianame';

        }

        $performancecriterias = self::constperformancecriterias();;

        list($relatedperformancecriteriassql, $relatedperformancecriteriasparams) = $DB->get_in_or_equal(array_flip($performancecriterias), SQL_PARAMS_NAMED, 'performancecriterias',false);
        $params = $relatedperformancecriteriasparams;

        $sql = "SELECT cmt.criterianame,$crtitlefield as fullname FROM {local_competency_pc} AS cmt
                WHERE cmt.criterianame $relatedperformancecriteriassql ";

        if (!empty($searchparams)) {

            $sql .= " AND ($crtitlefield LIKE :search )";
            $params['search'] = '%' . $searchparams . '%';

        }

        $competenciepccriterias=$DB->get_records_sql_menu($sql,$params,$limitfrom,$limitnum);

        if (!empty($searchparams)) {
            
            return $competenciepccriterias;
        }

        $competenciepccriterias[self::OTHER] = get_string('other','local_competency');
            
        return array_merge($performancecriterias,$competenciepccriterias);
            
    }

    public static function competency_kpi($searchparams,$limitfrom=0, $limitnum=0) {

        global $DB, $USER;

        $kpis = self::constkpis();

        $currentlang= current_language();

         if($currentlang == 'ar'){

            $kptitlefield='cmt.kpinamearabic';

        }else{

           $kptitlefield='cmt.kpiname';

        }


        list($relatedkpissql, $relatedkpisparams) = $DB->get_in_or_equal(array_flip($kpis), SQL_PARAMS_NAMED, 'kpis',false);
        $params = $relatedkpisparams;

        $sql = "SELECT cmt.kpiname,$kptitlefield as fullname FROM {local_competency_pc} AS cmt
                WHERE cmt.kpiname $relatedkpissql ";

        if (!empty($searchparams)) {

            $sql .= " AND ($kptitlefield LIKE :search )";
            $params['search'] = '%' . $searchparams . '%';

        }

        $competenciepckpis=$DB->get_records_sql_menu($sql,$params,$limitfrom,$limitnum);

        if (!empty($searchparams)) {
            
            return $competenciepckpis;
        }

        $competenciepckpis[self::OTHER] = get_string('other','local_competency');
            
        return array_merge($kpis,$competenciepckpis);
            
    }
    public static function competency_jobroleresponsibility($jobroleid) {

        global $DB, $USER;

   

        $jobroleresponsibilities= $DB->get_records_sql_menu('SELECT jbrspn.id,jbrspn.responsibility FROM {local_jobrole_responsibility} as jbrspn JOIN {local_jobrole_level} as jbrl on jbrl.id=jbrspn.roleid WHERE jbrl.id=:jobroleid',['jobroleid' => $jobroleid]);

        

        return $jobroleresponsibilities;
            
    }
    public static function competency_jobrole_levels($competencyid,$type='string') {

        global $DB, $USER;

        if($type=='string'){

            $jobrole= $DB->get_field_sql('SELECT cmtc.level 
                                                        FROM {local_competencies} as cmtc 
                                                     WHERE cmtc.id=:competencyid',['competencyid' => $competencyid]);
        }else{

            $jobrolelevel= $DB->get_field_sql('SELECT cmtc.level 
                                                        FROM {local_competencies} as cmtc 
                                                     WHERE cmtc.id=:competencyid',['competencyid' => $competencyid]);

            $jobrole= explode(',',$jobrolelevel);

        }

        return $jobrole;
            
    }
    public static function competency_objective($searchparams,$limitfrom=0, $limitnum=0) {

        global $DB, $USER;

        $currentlang= current_language();

        if($currentlang == 'ar'){

            $objtitlefield='cmt.objectiveidarabic';


        }else{

           $objtitlefield='cmt.objectiveid';
        }

        $objectives = self::constobjectives();


        list($relatedobjectivessql, $relatedobjectivesparams) = $DB->get_in_or_equal(array_flip($objectives), SQL_PARAMS_NAMED, 'objectives',false);
        $params = $relatedobjectivesparams;

        $sql = "SELECT cmt.objectiveid,$objtitlefield as fullname FROM {local_competency_pc} AS cmt
                WHERE cmt.objectiveid $relatedobjectivessql ";

        if (!empty($searchparams)) {

            $sql .= " AND ($objtitlefield LIKE :search )";
            $params['search'] = '%' . $searchparams . '%';

        }

        $competenciepcobjectives=$DB->get_records_sql_menu($sql,$params,$limitfrom,$limitnum);

        if (!empty($searchparams)) {
            
            return $competenciepcobjectives;
        }


        $competenciepcobjectives[self::OTHER] =get_string('other','local_competency');
            
        return array_merge($objectives,$competenciepcobjectives);
    }
    public static function get_mycompetencies($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $competencies      = array();
        $competenciescount = 0;
        $concatsql       = '';

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $cmtitlefield='cmt.arabicname';

        }else{

           $cmtitlefield='cmt.name';
        }

        $userinfo=self::userjobrolelevelinfo();


        if($stable->nextlevel){

            $concatsql .= " AND FIND_IN_SET($userinfo->nextjobroleid,cmt.jobroleid) > 0";


        }elseif($stable->supportedcompetencies){

            $concatsql .= " AND (EXISTS (SELECT trgprgm.id FROM {local_trainingprogram} AS trgprgm
                                        JOIN {program_enrollments} AS penrl ON penrl.programid=trgprgm.id WHERE FIND_IN_SET(cmt.id,trgprgm.competencyandlevels) > 0 AND penrl.userid=:penrluserid) > 0 OR EXISTS (SELECT exm.id FROM {local_exams} AS exm
                                        JOIN {exam_enrollments} AS exmnrl ON exmnrl.examid=exm.id WHERE FIND_IN_SET(cmt.id,exm.competencies) > 0 AND exmnrl.userid=:exmnrluserid) > 0)";

             $params['penrluserid'] = $USER->id;  
             $params['exmnrluserid'] = $USER->id;                          

        }else{

             $concatsql .= " AND FIND_IN_SET($userinfo->currentjobroleid,cmt.jobroleid) > 0";


        }

        if (!empty($filterdata->search_query)) {


            $fields = array(
                $cmtitlefield,"cmt.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            $concatsql .= " AND cmt.id = :competencyid";
            $params['competencyid'] = $stable->competencyid;
        }

        $countsql = "SELECT COUNT(cmt.id) ";
        $fromsql = "SELECT cmt.*,$cmtitlefield as name ";
        $sql = " FROM {local_competencies} AS cmt
                WHERE cmt.id > 0 ";


        $sql .= $concatsql;


        if(!empty($filterdata->type)){

            if(!empty($filterdata->type)){
                $typelist = explode(',',$filterdata->type);
            }
    
            list($relatedtypelistsql, $relatedtypelistparams) = $DB->get_in_or_equal($typelist, SQL_PARAMS_NAMED, 'typelist');
            $params = array_merge($params,$relatedtypelistparams);
            $sql .= " AND cmt.type $relatedtypelistsql";

        }

        if(!empty($filterdata->level)){

            if(!empty($filterdata->level)){
                $levellist = explode(',',$filterdata->level);
            }
    
            list($relatedlevellistsql, $relatedlevellistparams) = $DB->get_in_or_equal($levellist, SQL_PARAMS_NAMED, 'levellist');
            $params = array_merge($params,$relatedlevellistparams);
            $sql .= " AND cmt.level $relatedlevellistsql";

        }

        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            $competencies = $DB->get_record_sql($fromsql . $sql, $params);
        } else {
            try {

                $competenciescount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY cmt.id DESC";

                    $competencies = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $competenciescount = 0;
            }
        }
        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            return $competencies;
        } else {
            return compact('competencies', 'competenciescount');
        }
    }
    public static function get_myallcompetencies($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $competencies      = array();
        $competenciescount = 0;
        $concatsql       = '';


        $currentlang= current_language();

        if($currentlang == 'ar'){

           $cmtitlefield='cmt.arabicname';

        }else{

           $cmtitlefield='cmt.name';
        }

        $userinfo=self::userjobrolelevelinfo();

        if (!empty($filterdata->search_query)) {


            $fields = array(
                $cmtitlefield,"cmt.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            $concatsql .= " AND cmt.id = :competencyid";
            $params['competencyid'] = $stable->competencyid;
        }

        $countsql = "SELECT COUNT(cmt.id) ";
        $fromsql = "SELECT cmt.*,$cmtitlefield as name ";
        $sql = " FROM {local_competencies} AS cmt
                 WHERE cmt.id > 0 ";

        $sql .= $concatsql;


        if(!empty($filterdata->type)){

            if(!empty($filterdata->type)){
                $typelist = explode(',',$filterdata->type);
            }
    
            list($relatedtypelistsql, $relatedtypelistparams) = $DB->get_in_or_equal($typelist, SQL_PARAMS_NAMED, 'typelist');
            $params = array_merge($params,$relatedtypelistparams);
            $sql .= " AND cmt.type $relatedtypelistsql";

        }

        if(!empty($filterdata->level)){

            if(!empty($filterdata->level)){
                $levellist = explode(',',$filterdata->level);
            }
    
            list($relatedlevellistsql, $relatedlevellistparams) = $DB->get_in_or_equal($levellist, SQL_PARAMS_NAMED, 'levellist');
            $params = array_merge($params,$relatedlevellistparams);
            $sql .= " AND cmt.level $relatedlevellistsql";

        }

        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            $competencies = $DB->get_record_sql($fromsql . $sql, $params);
        } else {
            try {
                $competenciescount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY cmt.id DESC";

                    $competencies = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $competenciescount = 0;
            }
        }
        if (isset($stable->competencyid) && $stable->competencyid > 0) {
            return $competencies;
        } else {
            return compact('competencies', 'competenciescount');
        }
    }
    public static function get_objectives_exams_info($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $exams      = array();
        $examscount = 0;
        $concatsql       = '';

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $examtitlefield='exm.examnamearabic';

        }else{

           $examtitlefield='exm.exam';
        }

        if (!empty($filterdata->search_query)) {
            $fields = array(
                $examtitlefield,"exm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $countsql = "SELECT COUNT(exm.id) ";
        $fromsql = "SELECT exm.id as examid,$examtitlefield as examname,exm.code as examcode,cpcbj.competencypc,exm.courseid ";
        $sql = " FROM {local_exams} AS exm
                JOIN {local_competencypc_obj} AS cpcbj ON FIND_IN_SET(exm.id,cpcbj.examids) > 0 
                WHERE cpcbj.competencypc=$filterdata->competencypcid ";

        $sql .= $concatsql;

        if (isset($stable->competencypcid) && $stable->competencypcid > 0) {

            $fromsql = "SELECT exm.id as examid,$examtitlefield as fullname,exm.courseid ";

            $exams = $DB->get_records_sql($fromsql . $sql, $params);

        } else {

            try {
        
                $examscount = $DB->count_records_sql($countsql . $sql, $params);

                if ($stable->thead == false) {
                    $sql .= " ORDER BY exm.id DESC";

                    $exams = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $examscount = 0;
            }
        }
        if (isset($stable->competencypcid) && $stable->competencypcid > 0) {

            return $exams;

        } else {

            return compact('exams', 'examscount');

        }
    }
    public static function get_objectives_trainingprograms_info($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $trainingprograms      = array();
        $trainingprogramscount = 0;
        $concatsql       = '';

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $programtitlefield='trgprgm.namearabic';

        }else{

           $programtitlefield='trgprgm.name';
        }

        if (!empty($filterdata->search_query)) {
            $fields = array(
                $programtitlefield,"trgprgm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $countsql = "SELECT COUNT(trgprgm.id) ";
        $fromsql = "SELECT trgprgm.id as trgprgmid,$programtitlefield as trgprgmname,trgprgm.code as trgprgmcode,cpcbj.competencypc,trgprgm.courseid ";

        $sql = " FROM {local_trainingprogram} AS trgprgm
                JOIN {local_competencypc_obj} AS cpcbj ON FIND_IN_SET(trgprgm.id,cpcbj.trainingprogramids) > 0
                WHERE cpcbj.competencypc=$filterdata->competencypcid ";

        $sql .= $concatsql;



        if (isset($stable->competencypcid) && $stable->competencypcid > 0) {

            $fromsql = "SELECT trgprgm.id as trgprgmid,$programtitlefield as fullname,trgprgm.courseid ";

            $trainingprograms = $DB->get_records_sql($fromsql . $sql, $params);

        } else {

            try {
                $trainingprogramscount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY trgprgm.id DESC";

                    $trainingprograms = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {

                $trainingprogramscount = 0;

            }

        }
        if (isset($stable->competencypcid) && $stable->competencypcid > 0) {

            return $trainingprograms;

        } else {

            return compact('trainingprograms', 'trainingprogramscount');
        }
        
    }
    public static function get_objectives_questions_info($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $questions      = array();
        $questionscount = 0;
        $concatsql       = '';

        if (!empty($filterdata->search_query)) {
            $fields = array(
                "q.questiontext","q.qtype"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $countsql = "SELECT COUNT(q.id) ";
        $fromsql = "SELECT q.id as qid,q.questiontext as qname,q.qtype as qqtype,cpcbj.competencypc ";
        $sql = " FROM {question} AS q
                JOIN {local_competencypc_obj} AS cpcbj ON FIND_IN_SET(q.id,cpcbj.questionids) > 0 
                WHERE cpcbj.competencypc=$filterdata->competencypcid ";

        $sql .= $concatsql;

        if (isset($stable->competencypcid) && $stable->competencypcid > 0) {

            $fromsql = "SELECT q.id as qid,CONCAT(q.qtype,' ',q.questiontext)  as fullname ";

            $questions = $DB->get_records_sql($fromsql . $sql, $params);

        } else {

            try {
        
                $questionscount = $DB->count_records_sql($countsql . $sql, $params);

                if ($stable->thead == false) {
                    $sql .= " ORDER BY q.id DESC";

                    $questions = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $questionscount = 0;
            }
        }
        if (isset($stable->competencypcid) && $stable->competencypcid > 0) {

            return $questions;

        } else {

            return compact('questions', 'questionscount');

        }
    }
    public static function get_objectives_levels_info($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $levels      = array();
        $levelscount = 0;
        $concatsql       = '';

        if (!empty($filterdata->search_query)) {
            $fields = array(
                "jbrl.level"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $countsql = "SELECT COUNT(jbrl.id) ";
        $fromsql = "SELECT jbrl.id as lvlid,jbrl.level as lvlname,cpcbj.competencypc ";
        $sql = " FROM {local_jobrole_level} as jbrl
                JOIN {local_competencypc_obj} AS cpcbj ON FIND_IN_SET(jbrl.id,cpcbj.jobrolelevelids) > 0 
                WHERE cpcbj.competencypc=$filterdata->competencypcid ";

        $sql .= $concatsql;

        if (isset($stable->competencypcid) && $stable->competencypcid > 0) {

            $fromsql = "SELECT jbrl.id as lvlid,jbrl.level as fullname ";

            $levels = $DB->get_records_sql($fromsql . $sql, $params);

        } else {

            try {
        
                $levelscount = $DB->count_records_sql($countsql . $sql, $params);

                if ($stable->thead == false) {
                    $sql .= " ORDER BY jbrl.id DESC";

                    $levels = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $levelscount = 0;
            }
        }
        if (isset($stable->competencypcid) && $stable->competencypcid > 0) {

            return $levels;

        } else {

            return compact('levels', 'levelscount');

        }
    }
    public static function competency_obj_exams($searchparams,$limitfrom=0, $limitnum=0,$parentid,$parentchildid) {

        global $DB, $USER;

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $examtitlefield='exm.examnamearabic';

        }else{

           $examtitlefield='exm.exam';
        }


        $sql = "SELECT exm.id as examid,$examtitlefield as fullname
                FROM {local_exams} AS exm 
                WHERE concat(',',exm.competencies,',' ) like '%,$parentid,%' AND EXISTS (SELECT cpcbj.examids FROM {local_competencypc_obj} AS cpcbj WHERE cpcbj.competencypc=:competencypc AND cpcbj.competency=:competency AND FIND_IN_SET(exm.id,cpcbj.examids) > 0) = 0 ";   

        $params=array('competencypc'=>$parentchildid,'competency'=>$parentid);       

        if (!empty($searchparams)) {

            $fields = array(
                $examtitlefield,"exm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' .$searchparams. '%';
            $params['search2'] = '%' .$searchparams. '%';
            $sql .= " AND ($fields) ";

        }

        $objexams=$DB->get_records_sql_menu($sql,$params,$limitfrom,$limitnum);
            
        return $objexams;
    }
    public static function competency_obj_jobrolelevels($searchparams,$limitfrom=0, $limitnum=0,$parentid,$parentchildid) {

        global $DB, $USER;


        $sql = "SELECT jbrl.id,jbrl.level 
                    FROM {local_jobrole_level} as jbrl
                    JOIN {local_competencies} as cmtc ON FIND_IN_SET(jbrl.id,cmtc.jobroleid) > 0
                    WHERE cmtc.id=$parentid  AND EXISTS (SELECT cpcbj.jobrolelevelids FROM {local_competencypc_obj} AS cpcbj WHERE cpcbj.competencypc=:competencypc AND cpcbj.competency=:competency AND FIND_IN_SET(jbrl.id,cpcbj.jobrolelevelids) > 0) = 0 ";

        $params=array('competencypc'=>$parentchildid,'competency'=>$parentid);       

        if (!empty($searchparams)) {

            $fields = array(
                "jbrl.level"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $params['search1'] = '%' .$searchparams. '%';
            $sql .= " AND ($fields) ";

        }

        $objjobrolelevels=$DB->get_records_sql_menu($sql,$params,$limitfrom,$limitnum);
            
        return $objjobrolelevels;
    }
    public static function competency_obj_trainingprograms($searchparams,$limitfrom=0, $limitnum=0,$parentid,$parentchildid) {

        global $DB, $USER;

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $programtitlefield='trgprgm.namearabic';

        }else{

           $programtitlefield='trgprgm.name';
        }

        $sql = "SELECT trgprgm.id as trgprgmid,$programtitlefield as fullname
                FROM {local_trainingprogram} AS trgprgm
                WHERE concat(',',trgprgm.competencyandlevels,',' ) like '%,$parentid,%' AND EXISTS (SELECT cpcbj.trainingprogramids FROM {local_competencypc_obj} AS cpcbj WHERE cpcbj.competencypc=:competencypc AND cpcbj.competency=:competency AND FIND_IN_SET(trgprgm.id,cpcbj.trainingprogramids) > 0) = 0 ";   

        $params=array('competencypc'=>$parentchildid,'competency'=>$parentid);      

        if (!empty($searchparams)) {

            $fields = array(
                $programtitlefield,"trgprgm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' .$searchparams. '%';
            $params['search2'] = '%' .$searchparams. '%';
            $sql .= " AND ($fields) ";

        }

        $objtrainingprograms=$DB->get_records_sql_menu($sql,$params,$limitfrom,$limitnum);
            
        return $objtrainingprograms;
    }
    public static function competency_obj_questions($searchparams,$limitfrom=0, $limitnum=0,$parentid,$parentchildid) {

        global $DB, $USER;

        $sql = "SELECT qbcmt.questionid,q.qtype,q.questiontext
                FROM {local_qb_competencies} AS qbcmt
                JOIN {question} q ON q.id=qbcmt.questionid
                WHERE concat(',',qbcmt.competency,',' ) like '%,$parentid,%' AND EXISTS (SELECT cpcbj.questionids FROM {local_competencypc_obj} AS cpcbj WHERE cpcbj.competencypc=:competencypc AND cpcbj.competency=:competency AND FIND_IN_SET(qbcmt.questionid,cpcbj.questionids) > 0) = 0 ";   

        $params=array('competencypc'=>$parentchildid,'competency'=>$parentid);      

        if (!empty($searchparams)) {

            $fields = array(
                "q.questiontext","q.qtype"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' .$searchparams. '%';
            $params['search2'] = '%' .$searchparams. '%';
            $sql .= " AND ($fields) ";

        }

        $objquestions=$DB->get_records_sql($sql,$params,$limitfrom,$limitnum);

        $objquestionsarray=array();

        foreach($objquestions as $objquestion){

            $objquestionsarray[$objquestion->questionid]=get_string('pluginname','qtype_'.$objquestion->qtype).' '.mb_convert_encoding(clean_text(html_to_text(html_entity_decode($objquestion->questiontext))), 'UTF-8');
        }
            
        return $objquestionsarray;
            
    }
    public static function competency_const_exams($exams) {

        global $DB, $USER;

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $examtitlefield='exm.examnamearabic';

        }else{

           $examtitlefield='exm.exam';
        }

        list($relatedexamslistsql, $relatedexamslistparams) = $DB->get_in_or_equal($exams, SQL_PARAMS_NAMED, 'examslist');
        $params = $relatedexamslistparams;

        $sql = "SELECT exm.id as examid,$examtitlefield as fullname
                FROM {local_exams} AS exm
                WHERE exm.id $relatedexamslistsql";        

        $objexams=$DB->get_records_sql_menu($sql,$params);
            
        return $objexams;
    }
    public static function competency_const_objjobrolelevels($jobrolelevels) {

        global $DB, $USER;

        list($relatedjobrolelevelslistsql, $relatedjobrolelevelslistparams) = $DB->get_in_or_equal($jobrolelevels, SQL_PARAMS_NAMED, 'jobrolelevelslist');
        $params = $relatedjobrolelevelslistparams;

        $sql = "SELECT jbrl.id,jbrl.level as fullname
                FROM {local_jobrole_level} AS jbrl
                WHERE jbrl.id $relatedjobrolelevelslistsql";        

        $objjobrolelevels=$DB->get_records_sql_menu($sql,$params);

            
        return $objjobrolelevels;
    }
    public static function competency_const_trainingprograms($trainingprograms) {

        global $DB, $USER;

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $programtitlefield='trgprgm.namearabic';

        }else{

           $programtitlefield='trgprgm.name';
        }
       
        
        list($relatedtrainingprogramslistsql, $relatedtrainingprogramslistparams) = $DB->get_in_or_equal($trainingprograms, SQL_PARAMS_NAMED, 'trainingprogramslist');

        $params = $relatedtrainingprogramslistparams;

        $sql = "SELECT trgprgm.id as trgprgmid,$programtitlefield as fullname
                FROM {local_trainingprogram} AS trgprgm
                WHERE trgprgm.id $relatedtrainingprogramslistsql "; 

        $objtrainingprograms=$DB->get_records_sql_menu($sql,$params);
            
        return $objtrainingprograms;
    }
    public static function competency_const_questions($questions) {

        global $DB, $USER;
       
        
        list($relatedquestionslistsql, $relatedquestionslistparams) = $DB->get_in_or_equal($questions, SQL_PARAMS_NAMED, 'questionslist');

        $params = $relatedquestionslistparams;

        $sql = "SELECT qbcmt.questionid,q.qtype,q.questiontext
                FROM {local_qb_competencies} AS qbcmt
                JOIN {question} q ON q.id=qbcmt.questionid
                WHERE qbcmt.questionid $relatedquestionslistsql "; 

        $objquestions=$DB->get_records_sql($sql,$params);

        $objquestionsarray=array();

        foreach($objquestions as $objquestion){

            $objquestionsarray[$objquestion->questionid]=get_string('pluginname','qtype_'.$objquestion->qtype).' '.mb_convert_encoding(clean_text(html_to_text(html_entity_decode($objquestion->questiontext))), 'UTF-8');
        }
            
        return $objquestionsarray;
        
    }
    public function delete_competencypc($competencypcid,$competencyid) {

        global $DB;

        if ($competencypcid > 0) {


            $competencypc=$DB->record_exists('local_competency_pc', ['id' => $competencypcid,'competency'=>$competencyid]);

            if($competencypc){


                $DB->delete_records('local_competency_pc', ['id' => $competencypcid,'competency'=>$competencyid]);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $competencypcid                         
                    );
                $event = \local_competency\event\competencypc_deleted::create($params)->trigger();
            }

            $competencypcobj=$DB->record_exists('local_competencypc_obj', ['competencypc' => $competencypcid,'competency'=>$competencyid]);

            if($competencypcobj){

                $objid = $DB->delete_records('local_competencypc_obj', ['competencypc' => $competencypcid,'competency'=>$competencyid]);
                $params = array(
                    'context' => context_system::instance(),        
                    'objectid' => $objid                         
                    );
                $event = \local_competency\event\competency_obj_deleted::create($params)->trigger();
            
            }

            return true;
        } 

        return false;
    }
    public function delete_competencypcobjective($competencypcid,$competencypcobjectiveid,$competencypcobjectivetype) {

        global $DB,$USER;

        if ($competencypcid > 0) {


            $sql ="SELECT cpcbj.id,cpcbj.examids,cpcbj.trainingprogramids,cpcbj.questionids,cpcbj.jobrolelevelids FROM {local_competencypc_obj} AS cpcbj 
                WHERE cpcbj.competencypc=:competencypc ";

            if($competencypcobjectivetype == 'level'){

                $sql.=" AND FIND_IN_SET($competencypcobjectiveid,cpcbj.jobrolelevelids) > 0";

            }elseif($competencypcobjectivetype == 'question'){

                $sql.=" AND FIND_IN_SET($competencypcobjectiveid,cpcbj.questionids) > 0";

            }elseif($competencypcobjectivetype == 'exam'){

                $sql.=" AND FIND_IN_SET($competencypcobjectiveid,cpcbj.examids) > 0";

            }else{

                $sql.=" AND FIND_IN_SET($competencypcobjectiveid,cpcbj.trainingprogramids) > 0 ";
            }


            $competencypcobj=$DB->get_record_sql($sql, ['competencypc' => $competencypcid]);

            if($competencypcobj){

                if($competencypcobjectivetype == 'level'){

                    $setfield=" jobrolelevelids=:objectives";

                    $objectives=implode(',',array_filter(array_diff(explode(',',$competencypcobj->jobrolelevelids), [$competencypcobjectiveid])));

                }elseif($competencypcobjectivetype == 'question'){

                    $learningitemtype='question';

                    $learningitemid=$competencypcobjectiveid;

                    $setfield=" questionids=:objectives";

                    $objectives=implode(',',array_filter(array_diff(explode(',',$competencypcobj->questionids), [$competencypcobjectiveid])));

                }elseif($competencypcobjectivetype == 'exam'){

                    $learningitemtype='exam';

                    $learningitemid=$competencypcobjectiveid;

                    $setfield=" examids=:objectives";

                    $objectives=implode(',',array_filter(array_diff(explode(',',$competencypcobj->examids), [$competencypcobjectiveid])));

                }else{

                    $learningitemtype='trainingprogram';

                    $learningitemid=$competencypcobjectiveid;

                    $setfield=" trainingprogramids=:objectives";

                    $objectives=implode(',',array_filter(array_diff(explode(',',$competencypcobj->trainingprogramids), [$competencypcobjectiveid])));

                }

                $DB->execute('update {local_competencypc_obj} set '.$setfield.', timemodified=:timemodified, usermodified=:usermodified where id=:competencypcobjid' ,
                         ['objectives'=>$objectives,'timemodified'=>time(),'usermodified'=>$USER->id,'competencypcobjid' => $competencypcobj->id]);
                $params = array(
                            'context' => context_system::instance(),        
                            'objectid' => $competencypcobj->id                         
                            );

                $event = \local_competency\event\competency_obj_deleted::create($params)->trigger();
                $competenctid=$DB->get_field('local_competencypc_obj','competency',array('id'=>$competencypcobj->id ));


                if($competencypcobjectivetype != 'level'){     

                    $data->learningitemtype=$learningitemtype;

                    $data->learningitemid=$learningitemid;

                    $data->competency_name=$DB->get_field('local_competencies','name',array('id'=>$competenctid));

                    (new \local_competency\notification())->competency_notification('competency_removing_learning_item', $touser=get_admin(),$fromuser=get_admin(),$data,$waitinglistid=0);

                }
                

            }

            return true;
        } 

        return false;
    }
    public static function get_competency_exams_info($stable,$filterdata=null) {

        global $DB, $USER;

        $params          = array();
        $exams      = array();
        $examscount = 0;
        $concatsql       = '';

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $examtitlefield='exm.examnamearabic';

        }else{

           $examtitlefield='exm.exam';
        }

        if (!empty($filterdata->search_query)) {
            $fields = array(
                $examtitlefield,"exm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $countsql = "SELECT COUNT(exm.id) ";
        $fromsql = "SELECT exm.id as examid,$examtitlefield as examname,exm.code as examcode,exm.courseid ";
        $sql = " FROM {local_exams} AS exm 
                WHERE concat(',',exm.competencies,',' ) like '%,$stable->competencyid,%'  "; 

        $sql .= $concatsql;

        try {
    
            $examscount = $DB->count_records_sql($countsql . $sql, $params);

            if ($stable->thead == false) {
                $sql .= " ORDER BY exm.id DESC";

                $exams = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
            }
        } catch (dml_exception $ex) {
            $examscount = 0;
        }
        
        return compact('exams', 'examscount');
     
    }
    public static function get_competency_trainingprograms_info($stable,$filterdata=null) {

        global $DB, $USER;

        $params          = array();
        $trainingprograms      = array();
        $trainingprogramscount = 0;
        $concatsql       = '';


        $currentlang= current_language();

        if($currentlang == 'ar'){

           $programtitlefield='trgprgm.namearabic';

        }else{

           $programtitlefield='trgprgm.name';
        }

        if (!empty($filterdata->search_query)) {
            $fields = array(
                $programtitlefield,"trgprgm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $countsql = "SELECT COUNT(trgprgm.id) ";
        $fromsql = "SELECT trgprgm.id as trgprgmid,$programtitlefield as trgprgmname,trgprgm.code as trgprgmcode,trgprgm.courseid ";

        $sql = " FROM {local_trainingprogram} AS trgprgm
                WHERE concat(',',trgprgm.competencyandlevels,',' ) like '%,$stable->competencyid,%'";

        $sql .= $concatsql;
     

        try {
            $trainingprogramscount = $DB->count_records_sql($countsql . $sql, $params);
            if ($stable->thead == false) {
                $sql .= " ORDER BY trgprgm.id DESC";

                $trainingprograms = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
            }
        } catch (dml_exception $ex) {

            $trainingprogramscount = 0;

        }

        return compact('trainingprograms', 'trainingprogramscount');
    }
    public function update_competency_trainingprogram_status($competencytp) {

        global $DB, $USER;

        $competency_tp         = new stdClass();
        $competency_tp->trainingprogramid     = $competencytp->programid;
        $competency_tp->competencyid     = $competencytp->competencyid;
        $competency_tp->competencypcid     = $competencytp->competencypcid;
        $competency_tp->userid     = $competencytp->userid;

        $completions=$DB->get_record('local_cmtncypc_completions',array('trainingprogramid'=>$competency_tp->trainingprogramid,'competencyid'=>$competency_tp->competencyid,'competencypcid'=>$competency_tp->competencypcid,'userid'=>$competency_tp->userid),'id,completion_status');
        
        try {

            $competency_tp->completion_status = $competencytp->completion_status;
            $competency_tp->completiondate = time();

            if($completions){

                $competency_tp->id   = $completions->id;

                $competency_tp->usermodified   = $USER->id;
                $competency_tp->timemodified   = time();


                $DB->update_record('local_cmtncypc_completions', $competency_tp);

            }else{

                $competency_tp->usercreated   = $USER->id;
                $competency_tp->timecreated   = time();

                $competency_tp->id=$DB->insert_record('local_cmtncypc_completions', $competency_tp);

            }

            self::set_user_competencypc_completions($competency_tp);

        } catch (dml_exception $ex) {
            print_error($ex);
        }
        return true;
    } 
    public function update_competency_exam_status($competencyexam) {

        global $DB, $USER;
        
        $competency_exam         = new stdClass();
        $competency_exam->examid     = $competencyexam->examid;
        $competency_exam->competencyid     = $competencyexam->competencyid;
        $competency_exam->competencypcid     = $competencyexam->competencypcid;
        $competency_exam->userid     = $competencyexam->userid;

        $completions=$DB->get_record('local_cmtncypc_completions',array('examid'=>$competency_exam->examid,'competencyid'=>$competency_exam->competencyid,'competencypcid'=>$competency_exam->competencypcid,'userid'=>$competency_exam->userid),'id,completion_status');
        
        try {

            $competency_exam->completion_status = $competencyexam->completion_status;
            $competency_exam->completiondate = time();

            if($completions){

                $competency_exam->id   = $completions->id;

                $competency_exam->usermodified   = $USER->id;
                $competency_exam->timemodified   = time();


                $DB->update_record('local_cmtncypc_completions', $competency_exam);

            }else{

                $competency_exam->usercreated   = $USER->id;
                $competency_exam->timecreated   = time();

                $competency_exam->id=$DB->insert_record('local_cmtncypc_completions', $competency_exam);

            }

            self::set_user_competencypc_completions($competency_exam);

        } catch (dml_exception $ex) {
            print_error($ex);
        }
        return true;
    }
    public static function get_user_competencypc_completions($competencobj) {

        global $DB, $USER;

        $ttlcnt_cmpc_cmpln = array();
  
        $sql = "SELECT CASE WHEN examids='' THEN 0 ELSE LENGTH(examids)-LENGTH(REPLACE(examids,',',''))+1 END as totalexamscount,CASE WHEN trainingprogramids='' THEN 0 ELSE LENGTH(trainingprogramids)-LENGTH(REPLACE(trainingprogramids,',',''))+1 END as totalprogramscount FROM {local_competencypc_obj} WHERE competencypc=:competencypcid AND competency=:competencyid ";


        $params = array('competencypcid'=>$competencobj->competencypcid,'competencyid'=>$competencobj->competencyid);
    
        try {

            $competencypc_completions = $DB->get_record_sql($sql, $params);


            if($competencypc_completions){

                $ttlcnt_cmpc_cmpln=$competencypc_completions->totalexamscount+$competencypc_completions->totalprogramscount;

            }
            
        } catch (dml_exception $ex) {

            $ttlcnt_cmpc_cmpln = 0;

        }

        return $ttlcnt_cmpc_cmpln;
    }
    public static function set_user_competencypc_completions($competencobj) {

        global $DB, $USER;

        $set_cmpc_cmpln=false;

    
        try {

            $get_cmpc_cmpln=self::get_user_competencypc_completions($competencobj);


            if($get_cmpc_cmpln){

                $sql = "SELECT COUNT(id) FROM {local_cmtncypc_completions} WHERE competencyid=:competencyid AND userid=:userid AND completion_status=:completionstatus ";

                $params = array('competencyid'=>$competencobj->competencyid,'userid'=>$competencobj->userid,'completionstatus'=>$competencobj->completion_status);

                $user_cmpc_cmpln = $DB->count_records_sql($sql, $params);

                if($user_cmpc_cmpln > 0){

                    $sql = "SELECT CASE WHEN examids='' THEN 0 ELSE LENGTH(examids)-LENGTH(REPLACE(examids,',',''))+1 END as totalexamscount,CASE WHEN trainingprogramids='' THEN 0 ELSE LENGTH(trainingprogramids)-LENGTH(REPLACE(trainingprogramids,',',''))+1 END as totalprogramscount FROM {local_competencypc_obj} WHERE competency=:competencyid ";

                    $params = array('competencyid'=>$competencobj->competencyid);

                    $competencypc_completions = $DB->get_record_sql($sql, $params);

                    if($competencypc_completions){

                        $ttlcnt_cmpc_cmpln=$competencypc_completions->totalexamscount+$competencypc_completions->totalprogramscount;


                        if($ttlcnt_cmpc_cmpln > 0 && $user_cmpc_cmpln == $ttlcnt_cmpc_cmpln){

                            self::update_competency_completion_status($competencobj);
                        }

                    }
                }

            }
            
        } catch (dml_exception $ex) {

            $set_cmpc_cmpln=false;

        }

        return $set_cmpc_cmpln;
    }
    public static function update_competency_completion_status($competency) {

        global $DB, $USER;
        
        $usercompetency         = new stdClass();
        $usercompetency->competencyid     = $competency->competencyid;
        $usercompetency->userid     = $competency->userid;

        $completions=$DB->get_record('local_cmtncy_completions',array('competencyid'=>$usercompetency->competencyid,'userid'=>$usercompetency->userid),'id,completion_status');
        
        try {

            $usercompetency->completion_status = $competency->completion_status;
            $usercompetency->completiondate = time();

            if($completions){

                $usercompetency->id   = $completions->id;

                $usercompetency->usermodified   = $USER->id;
                $usercompetency->timemodified   = time();


                $DB->update_record('local_cmtncy_completions', $usercompetency);

                if($usercompetency->completion_status == 1){

                    $usercompetency->competency_name=$DB->get_field('local_competencies','name',array('id'=>$usercompetency->competencyid));
                   
                    $touser=$DB->get_record('user',array('id'=>$competency->userid));

                    $usercompetency->competency_userfulname=$touser->firstname. $touser->lastname;

                    (new \local_competency\notification())->competency_notification('competency_completions', $touser,$fromuser=get_admin(), $usercompetency,$waitinglistid=0);
                }

            }else{

                $usercompetency->usercreated   = $USER->id;
                $usercompetency->timecreated   = time();
                $usercompetency->id=$DB->insert_record('local_cmtncy_completions', $usercompetency);             
                if($usercompetency->completion_status == 1){

                    $usercompetency->competency_name=$DB->get_field('local_competencies','name',array('id'=>$usercompetency->competencyid));
                   
                    $touser=$DB->get_record('user',array('id'=>$competency->userid));

                    $usercompetency->competency_userfulname=$touser->firstname. $touser->lastname;

                    (new \local_competency\notification())->competency_notification('competency_completions', $touser,$fromuser=get_admin(), $usercompetency,$waitinglistid=0);
                    
                }
               
            }                                                                                                                                                                                              

        } catch (dml_exception $ex) {
            print_error($ex);
        }
        return true;
    }
    public static function get_supportedcompetency_exams_info($stable,$filterdata=null) {

        global $DB, $USER;

        $params          = array();
        $exams      = array();
        $examscount = 0;
        $concatsql       = '';

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $examtitlefield='exm.examnamearabic';

        }else{

           $examtitlefield='exm.exam';
        }

        if (!empty($filterdata->search_query)) {
            $fields = array(
                $examtitlefield,"exm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }
        
        $countsql = "SELECT COUNT(exm.id) ";
        $fromsql = "SELECT exm.id as examid,$examtitlefield as examname,exm.code as examcode,exm.courseid ";
        $sql = " FROM {local_exams} AS exm 
                 JOIN {exam_enrollments} AS exmnrl ON exmnrl.examid=exm.id 
                 WHERE concat(',',exm.competencies,',' ) like '%,$stable->competencyid,%' AND exmnrl.userid=:exmnrluserid "; 

        $params['exmnrluserid'] = $USER->id; 

        $sql .= $concatsql;

        try {
    
            $examscount = $DB->count_records_sql($countsql . $sql, $params);

            if ($stable->thead == false) {
                $sql .= " ORDER BY exm.id DESC";

                $exams = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
            }
        } catch (dml_exception $ex) {
            $examscount = 0;
        }
        
        return compact('exams', 'examscount');
     
    }
    public static function get_supportedcompetency_trainingprograms_info($stable,$filterdata=null) {

        global $DB, $USER;

        $params          = array();
        $trainingprograms      = array();
        $trainingprogramscount = 0;
        $concatsql       = '';

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $programtitlefield='trgprgm.namearabic';

        }else{

           $programtitlefield='trgprgm.name';
        }

        if (!empty($filterdata->search_query)) {
            $fields = array(
                $programtitlefield,"trgprgm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $countsql = "SELECT COUNT(trgprgm.id) ";
        $fromsql = "SELECT trgprgm.id as trgprgmid,$programtitlefield as trgprgmname,trgprgm.code as trgprgmcode,trgprgm.courseid ";

        $sql = " FROM {local_trainingprogram} AS trgprgm
                 JOIN {program_enrollments} AS penrl ON penrl.programid=trgprgm.id
                 WHERE concat(',',trgprgm.competencyandlevels,',' ) like '%,$stable->competencyid,%' AND penrl.userid=:penrluserid ";

        $params['penrluserid'] = $USER->id; 

        $sql .= $concatsql;
     

        try {
            $trainingprogramscount = $DB->count_records_sql($countsql . $sql, $params);
            if ($stable->thead == false) {
                $sql .= " ORDER BY trgprgm.id DESC";

                $trainingprograms = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
            }
        } catch (dml_exception $ex) {

            $trainingprogramscount = 0;

        }

        return compact('trainingprograms', 'trainingprogramscount');
    }
    public static function get_user_exams_check($examid) {

        global $DB, $USER;

        $params          = array();
        $examscount = 0;
   
        $countsql = "SELECT COUNT(exm.id) ";
   
        $sql = " FROM {local_exams} AS exm 
                 JOIN {exam_enrollments} AS exmnrl ON exmnrl.examid=exm.id 
                 WHERE exm.id=:exmid AND exmnrl.userid=:exmnrluserid "; 

        $params['exmnrluserid'] = $USER->id; 
        $params['exmid'] = $examid;


        try {
    
            $examscount = $DB->count_records_sql($countsql . $sql, $params);

        } catch (dml_exception $ex) {

            $examscount = 0;

        }
        
        return $examscount;
     
    }
    public static function get_user_trainingprograms_check($programid) {

        global $DB, $USER;

        $params          = array();
        $trainingprogramscount = 0;

        $countsql = "SELECT COUNT(trgprgm.id) ";


        $sql = " FROM {local_trainingprogram} AS trgprgm
                 JOIN {program_enrollments} AS penrl ON penrl.programid=trgprgm.id
                 WHERE trgprgm.id=:prgmid AND penrl.userid=:penrluserid ";

        $params['penrluserid'] = $USER->id; 
        $params['prgmid'] = $programid;

        try {
            $trainingprogramscount = $DB->count_records_sql($countsql . $sql, $params);

        } catch (dml_exception $ex) {

            $trainingprogramscount = 0;

        }

        return $trainingprogramscount;
    }
    public static function get_questionexperts($questionid) {

        global $DB, $USER;

        $currentlang= current_language();

        if($currentlang == 'ar'){

          $titlefield="CONCAT(lu.firstnamearabic,' ',lu.lastnamearabic)";

        }else{

           $titlefield="CONCAT(lu.firstname,' ',lu.lastname)";
        }
           
       

        $params =array('questionid'=>$questionid);

        $sql = "SELECT u.id,$titlefield as fullname
                FROM {local_qb_competencies} AS qbcmt
                JOIN {local_qb_experts} qexp ON qexp.questionbankid=qbcmt.questionbankid
                JOIN {user} AS u ON u.id=qexp.expertid
                JOIN {local_users} AS lu ON lu.userid=u.id
                WHERE qbcmt.questionid =:questionid "; 

        $questionexperts=$DB->get_records_sql_menu($sql,$params);
            
        return $questionexperts;
    }
    public static function get_competency_level_exams_info($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $exams      = array();
        $examscount = 0;
        $concatsql       = '';

        $currentlang= current_language();

        if($currentlang == 'ar'){

           $examtitlefield='exm.examnamearabic';

        }else{

           $examtitlefield='exm.exam';
        }

        if (!empty($filterdata->search_query)) {
            $fields = array(
                $examtitlefield,"exm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $level =  get_string($stable->level,'local_competency');

        $countsql = "SELECT COUNT(exm.id) ";
        $fromsql = "SELECT exm.id as examid,$examtitlefield as examname,exm.code as examcode,exm.courseid ";
        $sql = " FROM {local_exams} AS exm
                WHERE exm.competencies LIKE '%$stable->competencyid%' AND FIND_IN_SET('$level', exm.clevels) > 0";

        $sql .= $concatsql;

        if (isset($stable->level) && $stable->level) {

            $fromsql = "SELECT exm.id as examid,$examtitlefield as fullname,exm.courseid ";

            $exams = $DB->get_records_sql($fromsql . $sql, $params);

        } else {

            try {
        
                $examscount = $DB->count_records_sql($countsql . $sql, $params);

                if ($stable->thead == false) {
                    $sql .= " ORDER BY exm.id DESC";

                    $exams = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {
                $examscount = 0;
            }
        }
        if (isset($stable->level) && $stable->level) {

            return $exams;

        } else {

            return compact('exams', 'examscount');

        }
    }
    public static function get_competency_level_trainingprograms_info($stable,$filterdata=null) {
        global $DB, $USER;

        $params          = array();
        $trainingprograms      = array();
        $trainingprogramscount = 0;
        $concatsql       = '';

         $currentlang= current_language();

        if($currentlang == 'ar'){

           $programtitlefield='trgprgm.namearabic';

        }else{

           $programtitlefield='trgprgm.name';
        }

        if (!empty($filterdata->search_query)) {
            $fields = array(
                $programtitlefield,"trgprgm.code"
            );
            $fields = implode(" LIKE :search1 OR ", $fields);
            $fields .= " LIKE :search2 ";
            $params['search1'] = '%' . $filterdata->search_query . '%';
            $params['search2'] = '%' . $filterdata->search_query . '%';
            $concatsql .= " AND ($fields) ";
        }

        $level =  get_string($stable->level,'local_competency');

        $countsql = "SELECT COUNT(trgprgm.id) ";
        $fromsql = "SELECT trgprgm.id as trgprgmid,$programtitlefield as trgprgmname,trgprgm.code as trgprgmcode,trgprgm.courseid ";

        $sql = " FROM {local_trainingprogram} AS trgprgm
                 WHERE trgprgm.competencyandlevels LIKE '%$stable->competencyid%' AND  FIND_IN_SET('$level', trgprgm.clevels) > 0";

        $sql .= $concatsql;


        if (isset($stable->level) && $stable->level) {

            $fromsql = "SELECT trgprgm.id as trgprgmid,$programtitlefield as fullname,trgprgm.courseid ";
            $trainingprograms = $DB->get_records_sql($fromsql . $sql, $params);

        } else {

            try {
                $trainingprogramscount = $DB->count_records_sql($countsql . $sql, $params);
                if ($stable->thead == false) {
                    $sql .= " ORDER BY trgprgm.id DESC";


                    $trainingprograms = $DB->get_records_sql($fromsql . $sql, $params, $stable->start, $stable->length);
                }
            } catch (dml_exception $ex) {

                $trainingprogramscount = 0;

            }

        }
        if (isset($stable->level) && $stable->level) {

            return $trainingprograms;

        } else {

            return compact('trainingprograms', 'trainingprogramscount');
        }
        
    }
    public function update_competency_trainingprogram_delete($trainingprogramid) {

        global $DB;

        if ($trainingprogramid > 0) {

            $sql ="SELECT cpcbj.id,cpcbj.trainingprogramids FROM {local_competencypc_obj} AS cpcbj 
                WHERE FIND_IN_SET($trainingprogramid,cpcbj.trainingprogramids) > 0 "; 

            $competencypcobjs=$DB->get_records_sql($sql);

            foreach($competencypcobjs as $competencypcobj){

                if($competencypcobj){


                    $setfield=" trainingprogramids=:objectives";

                    $objectives=implode(',',array_filter(array_diff(explode(',',$competencypcobj->trainingprogramids), [$trainingprogramid])));

                    
                    $DB->execute('update {local_competencypc_obj} set '.$setfield.', timemodified=:timemodified, usermodified=:usermodified where id=:competencypcobjid' ,
                         ['objectives'=>$objectives,'timemodified'=>time(),'usermodified'=>$USER->id,'competencypcobjid' => $competencypcobj->id]);
                     $params = array(
                        'context' => context_system::instance(),        
                        'objectid' => $competencypcobj->id                         
                        );
                    $event = \local_competency\event\competency_obj_deleted::create($params)->trigger();

                }
            }


            return true;
        } 

        return false;
    }
    public function update_competency_exam_delete($examid) {

        global $DB;

        if ($examid > 0) {

            $sql ="SELECT cpcbj.id,cpcbj.examids FROM {local_competencypc_obj} AS cpcbj 
                WHERE FIND_IN_SET($examid,cpcbj.examids) > 0 "; 

            $competencypcobjs=$DB->get_records_sql($sql);

            foreach($competencypcobjs as $competencypcobj){

                if($competencypcobj){


                    $setfield=" examids=:objectives";

                    $objectives=implode(',',array_filter(array_diff(explode(',',$competencypcobj->examids), [$examid])));

                    
                    $DB->execute('update {local_competencypc_obj} set '.$setfield.', timemodified=:timemodified, usermodified=:usermodified where id=:competencypcobjid' ,
                         ['objectives'=>$objectives,'timemodified'=>time(),'usermodified'=>$USER->id,'competencypcobjid' => $competencypcobj->id]);
                     $params = array(
                        'context' => context_system::instance(),        
                        'objectid' => $competencypcobj->id                         
                        );
                    $event = \local_competency\event\competency_obj_deleted::create($params)->trigger();

                }
            }

            return true;
        } 

        return false;
    }

    public static function is_competence_mapped($competencyid) {
        global $DB;

       $sql = " SELECT loc.id
                FROM {local_competencies} as loc
                JOIN {local_trainingprogram} as lot ON FIND_IN_SET(loc.id,lot.competencyandlevels) > 0 WHERE loc.id = $competencyid
                UNION ALL 
                SELECT loc.id 
                FROM {local_competencies} as loc
                JOIN {local_exams} as loe ON FIND_IN_SET(loc.id,loe.competencies) > 0 
                WHERE loc.id = $competencyid 
                UNION ALL 
                SELECT loc.id 
                FROM {local_competencies} as loc
                JOIN {local_questionbank} as loq ON FIND_IN_SET(loc.id,loq.competency) > 0 
                WHERE loc.id = $competencyid
                UNION ALL
                SELECT loc.id 
                FROM {local_competencies} as loc
                JOIN {local_learningtracks} as lol ON FIND_IN_SET(loc.id,lol.competency) > 0 
                WHERE loc.id = $competencyid 
                 ";
        $competency = $DB->record_exists_sql($sql);
        return $competency;  
    }
     public static function is_competence_trainee() {
        global $DB,$USER;

        $systemcontext = context_system::instance();

        $sql = "SELECT ra.id
                  FROM {role_assignments} ra, {role} r, {context} c
                 WHERE ra.userid =:userid
                       AND ra.roleid = r.id
                       AND ra.contextid = c.id
                       AND ra.contextid =:contextid AND r.shortname ='trainee' ";

        $roles=$DB->record_exists_sql($sql ,array('userid'=>$USER->id,'contextid'=>$systemcontext->id));
        if(empty($roles)){

            throw new required_capability_exception($systemcontext, 'local/competency:viewtraineecompetencies', 'nopermissions', '');

        }
    }  
    public static function competencyexams_datasubmit($data) {

        global $DB, $USER;

        try {

            foreach($data->exams as $examid){

                $sql = "SELECT exm.id.,exm.ctype,exm.competencies
                        FROM {local_exams} AS exm 
                        WHERE exm.id = $examid ";  
                                         
                $exam = $DB->get_record_sql($sql); 

                $row=array();

                $row['id'] = $exam->id;

                $row['ctype'] = implode(',',array_filter(array_diff(explode(',',$exam->ctype), [$data->type])));

                $row['competencies'] = implode(',',array_filter(array_diff(explode(',',$exam->competencies), [$data->competencyid])));

                $DB->update_record('local_exams', $row);
            }

        } catch (dml_exception $e) {
            print_error($e);

        }
        return true;
    }
    public static function competencyprograms_datasubmit($data) {

        global $DB, $USER;

        try {

            foreach($data->trainingprograms as $trainingprogramid){


                $sql = "SELECT trgprgm.id,trgprgm.competencyandlevels
                        FROM {local_trainingprogram} AS trgprgm 
                        WHERE trgprgm.id = '$trainingprogramid' ";  
                                         
                $program = $DB->get_record_sql($sql);

                $row=array();

                $row['id'] = $program->id;

                $row['competencyandlevels'] = implode(',',array_filter(array_diff(explode(',',$program->competencyandlevels), [$data->competencyid])));

                $DB->update_record('local_trainingprogram', $row);
            }

        } catch (dml_exception $e) {
            print_error($e);

        }
        return true;
    }
    public static function competencyquestions_datasubmit($data) {

        global $DB, $USER;

        try {

            foreach($data->questions as $questionid){


                $sql = "SELECT qbcmt.questionid,qbcmt.competency
                    FROM {local_qb_competencies} AS qbcmt
                    JOIN {question} q ON q.id=qbcmt.questionid
                    WHERE q.id = $questionid ";  
                                     
                $question = $DB->get_record_sql($sql);

                $row=array();

                $row['id'] = $question->questionid;

                $row['competency'] = implode(',',array_filter(array_diff(explode(',',$question->competency), [$data->competencyid])));

                $DB->update_record('local_qb_competencies', $row);
            }

        } catch (dml_exception $e) {
            print_error($e);

        }
        return true;
    }    
}
      
        
